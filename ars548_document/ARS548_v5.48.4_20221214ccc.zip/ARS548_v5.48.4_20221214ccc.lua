do
    SomeIpHeader = {
        proto = Proto("ARS548.SomeIpHeader", "ARS548 SomeIP Header"),

  
        fields = {
           
            serviceID = ProtoField.uint16("ARS548.ServiceID", "ServiceID", base.DEC),
            methodID = ProtoField.uint16("ARS548.MethodID", "MethodID", base.DEC),
            length = ProtoField.uint32("ARS548.Length", "Length", base.DEC),
            clientID = ProtoField.uint16("ARS548.ClientID", "ClientID", base.HEX),
            sessionID = ProtoField.uint16("ARS548.SessionID", "SessionID", base.HEX),
            protocolVersion = ProtoField.uint8("ARS548.ProtocolVersion", "ProtocolVersion", base.HEX),
            interfaceVersion = ProtoField.uint8("ARS548.InterfaceVersion", "InterfaceVersion", base.HEX),
            messageType = ProtoField.uint8("ARS548.MessageType", "MessageType", base.HEX),
            returnCode = ProtoField.uint8("ARS548.ReturnCode", "ReturnCode", base.HEX),
        }
    }

    local p_ARS548 = Proto("ARS548.Header", "ARS548.Header")

    
    p_ARS548.fields = SomeIpHeader.fields

    local p_ARS548_Payload = Proto("ARS548.Payload", "ARS548.Payload")

    local f_payload = ProtoField.bytes("ARS548.Payload", "Payload", base.NONE)
    p_ARS548_Payload.fields = { f_payload }

    -- E2E P07 Header  （ DetectionList and ObjectList）
    local p_ARS548_E2E_P07_Header = Proto("ARS548.E2E_P07_Header", "ARS548.E2E_P07_Header")

    local f_CRC = ProtoField.uint64("E2E_P07_Header.CRC", "CRC", base.DEC)
    local f_len = ProtoField.uint32("E2E_P07_Header.PayloadLength", "Length", base.DEC)
    local f_SQC = ProtoField.uint64("E2E_P07_Header.SQC", "SQC", base.DEC)
    local f_dataID = ProtoField.uint32("E2E_P07_Header.DataID", "DataID", base.DEC)
    p_ARS548_E2E_P07_Header.fields = { f_CRC, f_len, f_SQC, f_dataID }

    -- DetectionList
    p_ARS548_DetectionList = Proto("ARS548.DetectionList", "DetectionList")

    f_Timestamp_Nanoseconds = ProtoField.uint32("ARS548.DetectionList.Timestamp_Nanoseconds", "Timestamp Nanoseconds", base.DEC)
    f_Timestamp_Seconds = ProtoField.uint32("ARS548.DetectionList.Timestamp_Seconds", "Timestamp Seconds", base.DEC)
    f_Timestamp_SyncStatus = ProtoField.uint8("ARS548.DetectionList.Timestamp_SyncStatus", "Timestamp Sync Status", base.DEC)
    f_EventDataQualifier = ProtoField.uint32("ARS548.DetectionList.EventDataQualifier", "Event Data Qualifier", base.DEC)
    f_ExtendedQualifier = ProtoField.uint8("ARS548.DetectionList.ExtendedQualifier", "Extended Qualifier", base.DEC)
    f_Origin_InvalidFlags = ProtoField.uint16("ARS548.DetectionList.Origin_InvalidFlags", "Sensor Position Invalid flags", base.DEC)
    f_Origin_Xpos = ProtoField.float("ARS548.DetectionList.Origin_Xpos", "Sensor X Position", base.DEC)
    f_Origin_Xstd = ProtoField.float("ARS548.DetectionList.Origin_Xstd", "Sensor X Position STD", base.DEC)
    f_Origin_Ypos = ProtoField.float("ARS548.DetectionList.Origin_Ypos", "Sensor Y Position", base.DEC)
    f_Origin_Ystd = ProtoField.float("ARS548.DetectionList.Origin_Ystd", "Sensor Y Position STD", base.DEC)
    f_Origin_Zpos = ProtoField.float("ARS548.DetectionList.Origin_Zpos", "Sensor Z Position", base.DEC)
    f_Origin_Zstd = ProtoField.float("ARS548.DetectionList.Origin_Zstd", "Sensor Z Position STD", base.DEC)
    f_Origin_Roll = ProtoField.float("ARS548.DetectionList.Origin_Roll", "Sensor Roll Angle", base.DEC)
    f_Origin_Rollstd = ProtoField.float("ARS548.DetectionList.Origin_Rollstd", "Sensor Roll Angle STD", base.DEC)
    f_Origin_Pitch = ProtoField.float("ARS548.DetectionList.Origin_Pitch", "Sensor Pitch Angle", base.DEC)
    f_Origin_Pitchstd = ProtoField.float("ARS548.DetectionList.Origin_Pitchstd", "Sensor Pitch Angle STD", base.DEC)
    f_Origin_Yaw = ProtoField.float("ARS548.DetectionList.Origin_Yaw", "Sensor Yaw Angle", base.DEC)
    f_Origin_Yawstd = ProtoField.float("ARS548.DetectionList.Origin_Yawstd", "Sensor Yaw Angle STD", base.DEC)
    f_List_InvalidFlags = ProtoField.uint8("ARS548.DetectionList.List_InvalidFlags", "Invalid flags", base.DEC)
    f_List_objects = ProtoField.protocol("ARS548.DetectionList.List_objects", "Detection Array", base.None)

    f_List_RadVelDomain_Min = ProtoField.float("ARS548.DetectionList.List_RadVelDomain_Min", "Radial Velocity Domain Min", base.DEC)
    f_List_RadVelDomain_Max = ProtoField.float("ARS548.DetectionList.List_RadVelDomain_Max", "Radial Velocity Domain Max", base.DEC)
    f_List_NumOfDetections = ProtoField.uint32("ARS548.DetectionList.List_NumOfDetections", "Number of Detections", base.DEC)
    f_Aln_AzimuthCorrection = ProtoField.float("ARS548.DetectionList.Aln_AzimuthCorrection", "Azimuth Correction", base.DEC)
    f_Aln_ElevationCorrection = ProtoField.float("ARS548.DetectionList.Aln_ElevationCorrection", "Elevation Correction", base.DEC)

    p_ARS548_DetectionList.fields = { f_Timestamp_Nanoseconds, f_Timestamp_Seconds, f_Timestamp_SyncStatus, f_EventDataQualifier, f_ExtendedQualifier, f_Origin_InvalidFlags,
        f_Origin_Xpos, f_Origin_Xstd, f_Origin_Ypos, f_Origin_Ystd, f_Origin_Zpos, f_Origin_Zstd, f_Origin_Roll, f_Origin_Rollstd, f_Origin_Pitch, f_Origin_Pitchstd,
        f_Origin_Yaw, f_Origin_Yawstd, f_List_InvalidFlags, f_List_objects, f_List_RadVelDomain_Min, f_List_RadVelDomain_Max, f_List_NumOfDetections, f_Aln_AzimuthCorrection,
        f_Aln_ElevationCorrection
    }

    -- Detection
    local p_ARS548_Detection = Proto("ARS548.Detection", "Detection")

    local f_f_AzimuthAngle = ProtoField.float("ARS548.Detection.f_AzimuthAngle", "Detection Azimuth Angle", base.DEC)
    local f_f_AzimuthAngleSTD = ProtoField.float("ARS548.Detection.f_AzimuthAngleSTD", "Azimuth Angle Std", base.DEC)
    local f_u_InvalidFlags = ProtoField.uint8("ARS548.Detection.u_InvalidFlags", "Detection Invalid Flags", base.DEC)
    local f_f_ElevationAngle = ProtoField.float("ARS548.Detection.f_ElevationAngle", "Detection Elevation Angle", base.DEC)
    local f_f_ElevationAngleSTD = ProtoField.float("ARS548.Detection.f_ElevationAngleSTD", "Elevation Angle Std", base.DEC)
    local f_f_Range = ProtoField.float("ARS548.Detection.f_Range", "Detection Radial Distance", base.DEC)
    local f_f_RangeSTD = ProtoField.float("ARS548.Detection.f_RangeSTD", "Radial Distance Std", base.DEC)
    local f_f_RangeRate = ProtoField.float("ARS548.Detection.f_RangeRate", "Detection Radial Velocity", base.DEC)
    local f_f_RangeRateSTD = ProtoField.float("ARS548.Detection.f_RangeRateSTD", "Radial Velocity Std", base.DEC)
    local f_s_RCS = ProtoField.int8("ARS548.Detection.s_RCS", "Detecion RCS", base.DEC)
    local f_u_MeasurementID = ProtoField.uint16("ARS548.Detection.u_MeasurementID", "Detection ID", base.DEC)
    local f_u_PositivePredictiveValue = ProtoField.uint8("ARS548.Detection.u_PositivePredictiveValue", "Existence Probability", base.DEC)
    local f_u_Classification = ProtoField.uint8("ARS548.Detection.u_Classification", "Detection Classification", base.DEC)
    local f_u_MultiTargetProbability = ProtoField.uint8("ARS548.Detection.u_MultiTargetProbability", "Multi-Target Probability", base.DEC)
    local f_u_ObjectID = ProtoField.uint16("ARS548.Detection.u_ObjectID", "Associated Object", base.DEC)
    local f_u_AmbiguityFlag = ProtoField.uint8("ARS548.Detection.u_AmbiguityFlag", "Ambiguity Flag (tbd)", base.DEC)
    local f_u_SortIndex = ProtoField.uint16("ARS548.Detection.u_SortIndex", "Sort Index (tbd)", base.DEC)

    p_ARS548_Detection.fields = {
        f_f_AzimuthAngle, f_f_AzimuthAngleSTD, f_u_InvalidFlags, f_f_ElevationAngle, f_f_ElevationAngleSTD, f_f_Range, f_f_RangeSTD,
        f_f_RangeRate, f_f_RangeRateSTD, f_s_RCS, f_u_MeasurementID, f_u_PositivePredictiveValue, f_u_Classification, f_u_MultiTargetProbability,
        f_u_ObjectID, f_u_AmbiguityFlag, f_u_SortIndex
    }

    -- ObjectList
    local p_ARS548_ObjectList = Proto("ARS548.ObjectList", "ARS548.ObjectList")

    local f_ObjectList_Timestamp_Nanoseconds = ProtoField.uint32("ARS548.ObjectList.Timestamp_Nanoseconds", "Timestamp Nanoseconds", base.DEC)
    local f_ObjectList_Timestamp_Seconds = ProtoField.uint32("ARS548.ObjectList.Timestamp_Seconds", "Timestamp Seconds", base.DEC)
    local f_ObjectList_Timestamp_SyncStatus = ProtoField.uint8("ARS548.ObjectList.Timestamp_SyncStatus", "Timestamp Sync Status", base.DEC)
    local f_ObjectList_EventDataQualifier = ProtoField.uint32("ARS548.ObjectList.EventDataQualifier", "Event Data Qualifier", base.DEC)
    local f_ObjectList_ExtendedQualifier = ProtoField.uint8("ARS548.ObjectList.ExtendedQualifier", "Extended Qualifier", base.DEC)
    local f_ObjectList_NumOfObjects = ProtoField.uint8("ARS548.ObjectList.NumOfObjects", "Number of Objects", base.DEC)

    p_ARS548_ObjectList.fields = {
        f_ObjectList_Timestamp_Nanoseconds, f_ObjectList_Timestamp_Seconds, f_ObjectList_Timestamp_SyncStatus, f_ObjectList_EventDataQualifier,
        f_ObjectList_ExtendedQualifier, f_ObjectList_NumOfObjects
    }

    -- Object
    local p_ARS548_Object = Proto("ARS548.Object", "ARS548.Object")

    local f_object_u_StatusSensor = ProtoField.uint16("ARS548.Object.u_StatusSensor", "tbd", base.DEC)
    local f_object_u_ID = ProtoField.uint32("ARS548.Object.u_ID", "ID of object", base.DEC)
    local f_object_u_Age = ProtoField.uint16("ARS548.Object.u_Age", "Age of object [ms]", base.DEC)
    local f_object_u_StatusMeasurement = ProtoField.uint8("ARS548.Object.u_StatusMeasurement", "Object Status", base.DEC,{[0] = "Measured（已测量的/经测量验证的）",[1] = "New（新建的）",[2] = "Predicted（预测的）",[255] = "Invalid（无效值）"})
    local f_object_u_StatusMovement = ProtoField.uint8("ARS548.Object.u_StatusMovement", "Object Movement Status",base.DEC,{[0] = "Moved（运动的）",[1] = "Stationary（静止的）",[255] = "Invalid（无效值）"})
    local f_object_u_Position_InvalidFlags = ProtoField.uint16("ARS548.Object.u_Position_InvalidFlags", "tbd", base.DEC)
    local f_object_u_Position_Reference = ProtoField.uint8("ARS548.Object.u_Position_Reference", "Reference point position", base.DEC)
    local f_object_u_Position_X = ProtoField.float("ARS548.Object.u_Position_X", "X Position", base.DEC)
    local f_object_u_Position_X_STD = ProtoField.float("ARS548.Object.u_Position_X_STD", "X Position Std", base.DEC)
    local f_object_u_Position_Y = ProtoField.float("ARS548.Object.u_Position_Y", "Y Position", base.DEC)
    local f_object_u_Position_Y_STD = ProtoField.float("ARS548.Object.u_Position_Y_STD", "Y Position Std", base.DEC)
    local f_object_u_Position_Z = ProtoField.float("ARS548.Object.u_Position_Z", "Z Position", base.DEC)
    local f_object_u_Position_Z_STD = ProtoField.float("ARS548.Object.u_Position_Z_STD", "Z Position Std", base.DEC)
    local f_object_u_Position_CovarianceXY = ProtoField.float("ARS548.Object.u_Position_CovarianceXY", "Covariance X Y", base.DEC)
    local f_object_u_Position_Orientation = ProtoField.float("ARS548.Object.u_Position_Orientation", "Object Orientation", base.DEC)
    local f_object_u_Position_Orientation_STD = ProtoField.float("ARS548.Object.u_Position_Orientation_STD", "Orientation Std", base.DEC)
    local f_object_u_Existence_InvalidFlags = ProtoField.uint8("ARS548.Object.u_Existence_InvalidFlags", "Existence Invalid Flags", base.DEC)
    local f_object_u_Existence_Probability = ProtoField.float("ARS548.Object.u_Existence_Probability", "Probability of Existence", base.DEC)
    local f_object_u_Existence_PPV = ProtoField.float("ARS548.Object.u_Existence_PPV", "PPV", base.DEC)
    local f_object_u_Classification_Car = ProtoField.uint8("ARS548.Object.u_Classification_Car", "Car Classification [%]", base.DEC)
    local f_object_u_Classification_Truck = ProtoField.uint8("ARS548.Object.u_Classification_Truck", "Truck Classification [%]", base.DEC)
    local f_object_u_Classification_Motorcycle = ProtoField.uint8("ARS548.Object.u_Classification_Motorcycle", "Motorcycle Classification [%]", base.DEC)
    local f_object_u_Classification_Bicycle = ProtoField.uint8("ARS548.Object.u_Classification_Bicycle", "Bicycle Classification [%]", base.DEC)
    local f_object_u_Classification_Pedestrian = ProtoField.uint8("ARS548.Object.u_Classification_Pedestrian", "Pedestrian Classification [%]", base.DEC)
    local f_object_u_Classification_Animal = ProtoField.uint8("ARS548.Object.u_Classification_Animal", "Animal Classification [%]", base.DEC)
    local f_object_u_Classification_Hazard = ProtoField.uint8("ARS548.Object.u_Classification_Hazard", "Hazard Classification [%]", base.DEC)
    local f_object_u_Classification_Unknown = ProtoField.uint8("ARS548.Object.u_Classification_Unknown", "Unknown Classification [%]", base.DEC)
    local f_object_u_Classification_Overdrivable = ProtoField.uint8("ARS548.Object.u_Classification_Overdrivable", "Overdrivable Classification [%]", base.DEC)
    local f_object_u_Classification_Underdrivable = ProtoField.uint8("ARS548.Object.u_Classification_Underdrivable", "Underdrivable Classification [%]", base.DEC)
    local f_object_u_Dynamics_AbsVel_InvalidFlags = ProtoField.uint8("ARS548.Object.u_Dynamics_AbsVel_InvalidFlags", "Invalid Flags AbsVel", base.DEC)
    local f_object_f_Dynamics_AbsVel_X = ProtoField.float("ARS548.Object.f_Dynamics_AbsVel_X", "X Abs Vel", base.DEC)
    local f_object_f_Dynamics_AbsVel_X_STD = ProtoField.float("ARS548.Object.f_Dynamics_AbsVel_X_STD", "X Abs Vel Std", base.DEC)
    local f_object_f_Dynamics_AbsVel_Y = ProtoField.float("ARS548.Object.f_Dynamics_AbsVel_Y", "Y Abs Vel", base.DEC)
    local f_object_f_Dynamics_AbsVel_Y_STD = ProtoField.float("ARS548.Object.f_Dynamics_AbsVel_Y_STD", "Y Abs Vel Std", base.DEC)
    local f_object_f_Dynamics_AbsVel_CovarianceXY = ProtoField.float("ARS548.Object.f_Dynamics_AbsVel_CovarianceXY", "Covariance Abs Vel X Y", base.DEC)
    local f_object_u_Dynamics_RelVel_InvalidFlags = ProtoField.uint8("ARS548.Object.u_Dynamics_RelVel_InvalidFlags", "Invalid Flags RelVel", base.DEC)
    local f_object_f_Dynamics_RelVel_X = ProtoField.float("ARS548.Object.f_Dynamics_RelVel_X", "X Rel Vel", base.DEC)
    local f_object_f_Dynamics_RelVel_X_STD = ProtoField.float("ARS548.Object.f_Dynamics_RelVel_X_STD", "X Rel Vel Std", base.DEC)
    local f_object_f_Dynamics_RelVel_Y = ProtoField.float("ARS548.Object.f_Dynamics_RelVel_Y", "Y Rel Vel", base.DEC)
    local f_object_f_Dynamics_RelVel_Y_STD = ProtoField.float("ARS548.Object.f_Dynamics_RelVel_Y_STD", "Y Rel Vel Std", base.DEC)
    local f_object_f_Dynamics_RelVel_CovarianceXY = ProtoField.float("ARS548.Object.f_Dynamics_RelVel_CovarianceXY", "Covariance Rel Vel X Y", base.DEC)
    local f_object_u_Dynamics_AbsAccel_InvalidFlags = ProtoField.uint8("ARS548.Object.u_Dynamics_AbsAccel_InvalidFlags", "Invalid Flags AbsAccel", base.DEC)
    local f_object_f_Dynamics_AbsAccel_X = ProtoField.float("ARS548.Object.f_Dynamics_AbsAccel_X", "X Abs Accel", base.DEC)
    local f_object_f_Dynamics_AbsAccel_X_STD = ProtoField.float("ARS548.Object.f_Dynamics_AbsAccel_X_STD", "X Abs Accel Std", base.DEC)
    local f_object_f_Dynamics_AbsAccel_Y = ProtoField.float("ARS548.Object.f_Dynamics_AbsAccel_Y", "Y Abs Accel", base.DEC)
    local f_object_f_Dynamics_AbsAccel_Y_STD = ProtoField.float("ARS548.Object.f_Dynamics_AbsAccel_Y_STD", "Y Abs Accel Std", base.DEC)
    local f_object_f_Dynamics_AbsAccel_CovarianceXY = ProtoField.float("ARS548.Object.f_Dynamics_AbsAccel_CovarianceXY", "Covariance Abs Accel X Y", base.DEC)
    local f_object_u_Dynamics_RelAccel_InvalidFlags = ProtoField.uint8("ARS548.Object.u_Dynamics_RelAccel_InvalidFlags", "Invalid Flags RelAccel", base.DEC)
    local f_object_f_Dynamics_RelAccel_X = ProtoField.float("ARS548.Object.f_Dynamics_RelAccel_X", "X Rel Accel", base.DEC)
    local f_object_f_Dynamics_RelAccel_X_STD = ProtoField.float("ARS548.Object.f_Dynamics_RelAccel_X_STD", "X Rel Accel Std", base.DEC)
    local f_object_f_Dynamics_RelAccel_Y = ProtoField.float("ARS548.Object.f_Dynamics_RelAccel_Y", "Y Rel Accel", base.DEC)
    local f_object_f_Dynamics_RelAccel_Y_STD = ProtoField.float("ARS548.Object.f_Dynamics_RelAccel_Y_STD", "Y Rel Accel Std", base.DEC)
    local f_object_f_Dynamics_RelAccel_CovarianceXY = ProtoField.float("ARS548.Object.f_Dynamics_RelAccel_CovarianceXY", "Covariance Rel Accel X Y", base.DEC)
    local f_object_u_Dynamics_Orientation_InvalidFlags = ProtoField.uint8("ARS548.Object.u_Dynamics_Orientation_InvalidFlags", "Invalid Flags Orientation", base.DEC)
    local f_object_u_Dynamics_Orientation_Rate_Mean = ProtoField.float("ARS548.Object.u_Dynamics_Orientation_Rate_Mean", "Object Orientation Rate", base.DEC)
    local f_object_u_Dynamics_Orientation_Rate_STD = ProtoField.float("ARS548.Object.u_Dynamics_Orientation_Rate_STD", "Orientation Rate Std", base.DEC)
    local f_object_u_Shape_Length_Status = ProtoField.uint32("ARS548.Object.u_Shape_Length_Status", "Shape Length Status", base.DEC)
    local f_object_u_Shape_Length_Edge_InvalidFlags = ProtoField.uint8("ARS548.Object.u_Shape_Length_Edge_InvalidFlags", "Invalid Flags Shape Length", base.DEC)
    local f_object_u_Shape_Length_Edge_Mean = ProtoField.float("ARS548.Object.u_Shape_Length_Edge_Mean", "Mean Shape Length", base.DEC)
    local f_object_u_Shape_Length_Edge_STD = ProtoField.float("ARS548.Object.u_Shape_Length_Edge_STD", "Shape Length Std", base.DEC)
    local f_object_u_Shape_Width_Status = ProtoField.uint32("ARS548.Object.u_Shape_Width_Status", "Shape Width Status", base.DEC)
    local f_object_u_Shape_Width_Edge_InvalidFlags = ProtoField.uint8("ARS548.Object.u_Shape_Width_Edge_InvalidFlags", "Invalid Flags Shape Width", base.DEC)
    local f_object_u_Shape_Width_Edge_Mean = ProtoField.float("ARS548.Object.u_Shape_Width_Edge_Mean", "Mean Shape Width", base.DEC)
    local f_object_u_Shape_Width_Edge_STD = ProtoField.float("ARS548.Object.u_Shape_Width_Edge_STD", "Shape Width Std", base.DEC)

    p_ARS548_Object.fields = {
        f_object_u_StatusSensor, f_object_u_ID, f_object_u_Age, f_object_u_StatusMeasurement, f_object_u_StatusMovement, f_object_u_Position_InvalidFlags, f_object_u_Position_Reference,
        f_object_u_Position_X, f_object_u_Position_X_STD, f_object_u_Position_Y, f_object_u_Position_Y_STD, f_object_u_Position_Z, f_object_u_Position_Z_STD, f_object_u_Position_CovarianceXY,
        f_object_u_Position_Orientation, f_object_u_Position_Orientation_STD, f_object_u_Existence_InvalidFlags, f_object_u_Existence_Probability, f_object_u_Existence_PPV,
        f_object_u_Classification_Car, f_object_u_Classification_Truck, f_object_u_Classification_Motorcycle, f_object_u_Classification_Bicycle, f_object_u_Classification_Pedestrian,
        f_object_u_Classification_Animal, f_object_u_Classification_Hazard, f_object_u_Classification_Unknown, f_object_u_Classification_Overdrivable, f_object_u_Classification_Underdrivable,
        f_object_u_Dynamics_AbsVel_InvalidFlags, f_object_f_Dynamics_AbsVel_X, f_object_f_Dynamics_AbsVel_X_STD, f_object_f_Dynamics_AbsVel_Y, f_object_f_Dynamics_AbsVel_Y_STD,
        f_object_f_Dynamics_AbsVel_CovarianceXY, f_object_u_Dynamics_RelVel_InvalidFlags, f_object_f_Dynamics_RelVel_X, f_object_f_Dynamics_RelVel_X_STD, f_object_f_Dynamics_RelVel_Y,
        f_object_f_Dynamics_RelVel_Y_STD, f_object_f_Dynamics_RelVel_CovarianceXY, f_object_u_Dynamics_AbsAccel_InvalidFlags, f_object_f_Dynamics_AbsAccel_X, f_object_f_Dynamics_AbsAccel_X_STD,
        f_object_f_Dynamics_AbsAccel_Y, f_object_f_Dynamics_AbsAccel_Y_STD, f_object_f_Dynamics_AbsAccel_CovarianceXY, f_object_u_Dynamics_RelAccel_InvalidFlags, f_object_f_Dynamics_RelAccel_X,
        f_object_f_Dynamics_RelAccel_X_STD, f_object_f_Dynamics_RelAccel_Y, f_object_f_Dynamics_RelAccel_Y_STD, f_object_f_Dynamics_RelAccel_CovarianceXY, f_object_u_Dynamics_Orientation_InvalidFlags,
        f_object_u_Dynamics_Orientation_Rate_Mean, f_object_u_Dynamics_Orientation_Rate_STD, f_object_u_Shape_Length_Status, f_object_u_Shape_Length_Edge_InvalidFlags, f_object_u_Shape_Length_Edge_Mean,
        f_object_u_Shape_Length_Edge_STD, f_object_u_Shape_Width_Status, f_object_u_Shape_Width_Edge_InvalidFlags, f_object_u_Shape_Width_Edge_Mean, f_object_u_Shape_Width_Edge_STD
    }

    -- Landmarks
    local p_ARS548_Landmarks = Proto("ARS548.Landmarks", "ARS548.Landmarks")

    local f_Landmarks_EventDataQualifier = ProtoField.uint32("ARS548.Landmarks.EventDataQualifier", "Event Data Qualifier", base.DEC)
    local f_Landmarks_ExtendedQualifier = ProtoField.uint8("ARS548.Landmarks.ExtendedQualifier", "Extended Qualifier", base.DEC)
    local f_Landmarks_Timestamp_Nanoseconds = ProtoField.uint32("ARS548.Landmarks.Timestamp_Nanoseconds", "Timestamp Nanoseconds", base.DEC)
    local f_Landmarks_Timestamp_Seconds = ProtoField.uint32("ARS548.Landmarks.Timestamp_Seconds", "Timestamp Seconds", base.DEC)
    local f_Landmarks_Timestamp_SyncStatus = ProtoField.uint8("ARS548.Landmarks.Timestamp_SyncStatus", "Timestamp Sync Status", base.DEC)
    local f_Landmarks_InvalidFlags = ProtoField.uint8("ARS548.Landmarks.InvalidFlags", "Invalid flags", base.DEC)
    local f_Landmarks_MainHypothesis_RoadConfidence = ProtoField.float("ARS548.Landmarks.MainHypothesis_RoadConfidence", "Road Confidence", base.DEC)
    local f_Landmarks_MainHypothesis_LeftLateralOffset = ProtoField.float("ARS548.Landmarks.MainHypothesis_LeftLateralOffset", "Left Lateral Offset", base.DEC)
    local f_Landmarks_MainHypothesis_RightLateralOffset = ProtoField.float("ARS548.Landmarks.MainHypothesis_RightLateralOffset", "Right Lateral Offset", base.DEC)
    local f_Landmarks_MainHypothesis_HeadingAngle = ProtoField.float("ARS548.Landmarks.MainHypothesis_HeadingAngle", "Heading Angle", base.DEC)
    local f_Landmarks_MainHypothesis_Curvature = ProtoField.float("ARS548.Landmarks.MainHypothesis_Curvature", "Curvature", base.DEC)
    local f_Landmarks_MainHypothesis_CurvatureGradient = ProtoField.float("ARS548.Landmarks.MainHypothesis_CurvatureGradient", "Curvature Gradient", base.DEC)
    local f_Landmarks_MainHypothesis_TransitionPoint = ProtoField.float("ARS548.Landmarks.MainHypothesis_TransitionPoint", "Transition Point", base.DEC)
    local f_Landmarks_MainHypothesis_SecondCurvatureGradient = ProtoField.float("ARS548.Landmarks.MainHypothesis_SecondCurvatureGradient", "Second Curvature Gradient", base.DEC)
    local f_Landmarks_MainHypothesis_LeftDataSupportedRanges = ProtoField.float("ARS548.Landmarks.MainHypothesis_LeftDataSupportedRanges", "Left Data Ranges (Start/End)", base.DEC)
    local f_Landmarks_MainHypothesis_RightDataSupportedRanges = ProtoField.float("ARS548.Landmarks.MainHypothesis_RightDataSupportedRanges", "Right Data Ranges (Start/End)", base.DEC)
    local f_Landmarks_MainHypothesis_LeftRangeMax = ProtoField.float("ARS548.Landmarks.MainHypothesis_LeftRangeMax", "Max Range Left", base.DEC)
    local f_Landmarks_MainHypothesis_RightRangeMax = ProtoField.float("ARS548.Landmarks.MainHypothesis_RightRangeMax", "Max Range Right", base.DEC)
    local f_Landmarks_SecondHypothesis_RoadConfidence = ProtoField.float("ARS548.Landmarks.SecondHypothesis_RoadConfidence", "Road Confidence", base.DEC)
    local f_Landmarks_SecondHypothesis_HeadingAngle = ProtoField.float("ARS548.Landmarks.SecondHypothesis_HeadingAngle", "Heading Angle", base.DEC)
    local f_Landmarks_SecondHypothesis_Curvature = ProtoField.float("ARS548.Landmarks.SecondHypothesis_Curvature", "Curvature", base.DEC)
    local f_Landmarks_SecondHypothesis_CurvatureGradient = ProtoField.float("ARS548.Landmarks.SecondHypothesis_CurvatureGradient", "Curvature Gradient", base.DEC)
    local f_Landmarks_SecondHypothesis_LeftRangeMax = ProtoField.float("ARS548.Landmarks.SecondHypothesis_LeftRangeMax", "Max Range Left", base.DEC)
    local f_Landmarks_SecondHypothesis_RightRangeMax = ProtoField.float("ARS548.Landmarks.SecondHypothesis_RightRangeMax", "Max Range Right", base.DEC)
    local f_Landmarks_LaneMatrix_LeftLanes = ProtoField.int8("ARS548.Landmarks.LaneMatrix_LeftLanes", "Left Lanes", base.DEC)
    local f_Landmarks_LaneMatrix_RightLanes = ProtoField.int8("ARS548.Landmarks.LaneMatrix_RightLanes", "Right Lanes", base.DEC)
    local f_Landmarks_DistanceToBorder_Left = ProtoField.float("ARS548.Landmarks.DistanceToBorder_Left", "Distance to Left Border", base.DEC)
    local f_Landmarks_DistanceToBorder_Right = ProtoField.float("ARS548.Landmarks.DistanceToBorder_Right", "Distance to Right Border", base.DEC)
    local f_Landmarks_Tunnel_InvalidFlags = ProtoField.uint8("ARS548.Landmarks.Tunnel_InvalidFlags", "Invalid Flags", base.DEC)
    local f_Landmarks_Tunnel_Distance = ProtoField.float("ARS548.Landmarks.Tunnel_Distance", "Tunnel Distance", base.DEC)
    local f_Landmarks_Tunnel_ExistanceProbability = ProtoField.float("ARS548.Landmarks.Tunnel_ExistanceProbability", "Tunnel Existence Probability", base.DEC)

    p_ARS548_Landmarks.fields = {
        f_Landmarks_EventDataQualifier, f_Landmarks_ExtendedQualifier, f_Landmarks_Timestamp_Nanoseconds, f_Landmarks_Timestamp_Seconds,
        f_Landmarks_Timestamp_SyncStatus, f_Landmarks_InvalidFlags, f_Landmarks_MainHypothesis_RoadConfidence, f_Landmarks_MainHypothesis_LeftLateralOffset,
        f_Landmarks_MainHypothesis_RightLateralOffset, f_Landmarks_MainHypothesis_HeadingAngle, f_Landmarks_MainHypothesis_Curvature,
        f_Landmarks_MainHypothesis_CurvatureGradient, f_Landmarks_MainHypothesis_TransitionPoint, f_Landmarks_MainHypothesis_SecondCurvatureGradient,
        f_Landmarks_MainHypothesis_LeftDataSupportedRanges, f_Landmarks_MainHypothesis_RightDataSupportedRanges, f_Landmarks_MainHypothesis_LeftRangeMax,
        f_Landmarks_MainHypothesis_RightRangeMax, f_Landmarks_SecondHypothesis_RoadConfidence, f_Landmarks_SecondHypothesis_HeadingAngle,
        f_Landmarks_SecondHypothesis_Curvature, f_Landmarks_SecondHypothesis_CurvatureGradient, f_Landmarks_SecondHypothesis_LeftRangeMax,
        f_Landmarks_SecondHypothesis_RightRangeMax, f_Landmarks_LaneMatrix_LeftLanes, f_Landmarks_LaneMatrix_RightLanes, f_Landmarks_DistanceToBorder_Left,
        f_Landmarks_DistanceToBorder_Right, f_Landmarks_Tunnel_InvalidFlags, f_Landmarks_Tunnel_Distance, f_Landmarks_Tunnel_ExistanceProbability
    }


    -- FieldOfView
    local p_ARS548_FieldOfView = Proto("ARS548.FieldOfView", "ARS548.FieldOfView")

    local f_FieldOfView_Timestamp_Nanoseconds = ProtoField.uint32("ARS548.FieldOfView.Timestamp_Nanoseconds", "Timestamp Nanoseconds", base.DEC)
    local f_FieldOfView_Timestamp_Seconds = ProtoField.uint32("ARS548.FieldOfView.Timestamp_Seconds", "Timestamp Seconds", base.DEC)
    local f_FieldOfView_Timestamp_SyncStatus = ProtoField.uint8("ARS548.FieldOfView.Timestamp_SyncStatus", "Timestamp Sync Status", base.DEC)
    local f_FieldOfView_SensorStatus = ProtoField.uint8("ARS548.FieldOfView.SensorStatus", "Sensor Status", base.DEC)
    local f_FieldOfView_Regions = ProtoField.bytes("ARS548.FieldOfView.Regions", "Regions", base.None)

    p_ARS548_FieldOfView.fields = {
        f_FieldOfView_Timestamp_Nanoseconds, f_FieldOfView_Timestamp_Seconds, f_FieldOfView_Timestamp_SyncStatus, f_FieldOfView_SensorStatus,
        f_FieldOfView_Regions
    }

    -- FieldOfView.Region
    local p_ARS548_Region = Proto("ARS548.Region", "ARS548.Region")

    local f_Region_s_AzimuthRange_Start = ProtoField.int16("ARS548.Region.s_AzimuthRange_Start", "Region Azimuth Start", base.DEC)
    local f_Region_s_AzimuthRange_End = ProtoField.int16("ARS548.Region.s_AzimuthRange_End", "Region Azimuth End", base.DEC)
    local f_Region_f_MaximumDetectionRange_Pedestrian = ProtoField.float("ARS548.Region.f_MaximumDetectionRange_Pedestrian", "Maximum Pedestrian Detection Range", base.DEC)
    local f_Region_f_MaximumDetectionRange_Motorbike = ProtoField.float("ARS548.Region.f_MaximumDetectionRange_Motorbike", "Maximum Motorbike Detection Range", base.DEC)
    local f_Region_f_MaximumDetectionRange_Car = ProtoField.float("ARS548.Region.f_MaximumDetectionRange_Car", "Maximum Car Detection Range", base.DEC)
    local f_Region_u_InvalidFlags = ProtoField.uint8("ARS548.Region.u_InvalidFlags", "Invalid Flags", base.DEC)
    local f_Region_u_Blockage_Status = ProtoField.uint8("ARS548.Region.u_Blockage_Status", "Blockage Status", base.DEC)
    local f_Region_u_Blockage_Classification = ProtoField.uint8("ARS548.Region.u_Blockage_Classification", "Blockage Classification", base.DEC)

    p_ARS548_Region.fields = {
        f_Region_s_AzimuthRange_Start, f_Region_s_AzimuthRange_End, f_Region_f_MaximumDetectionRange_Pedestrian, f_Region_f_MaximumDetectionRange_Motorbike,
        f_Region_f_MaximumDetectionRange_Car, f_Region_u_InvalidFlags, f_Region_u_Blockage_Status, f_Region_u_Blockage_Classification
    }


    -- EgoSpeed
    local p_ARS548_EgoSpeed = Proto("ARS548.EgoSpeed", "ARS548.EgoSpeed")

    local f_EgoSpeed_Timestamp_Nanoseconds = ProtoField.uint32("ARS548.EgoSpeed.Timestamp_Nanoseconds", "Timestamp Nanoseconds", base.DEC)
    local f_EgoSpeed_Timestamp_Seconds = ProtoField.uint32("ARS548.EgoSpeed.Timestamp_Seconds", "Timestamp Seconds", base.DEC)
    local f_EgoSpeed_Timestamp_SyncStatus = ProtoField.uint8("ARS548.EgoSpeed.Timestamp_SyncStatus", "Timestamp Sync Status", base.DEC)
    local f_EgoSpeed_EventDataQualifier = ProtoField.uint32("ARS548.EgoSpeed.EventDataQualifier", "Event Data Qualifier", base.DEC)
    local f_EgoSpeed_ExtendedQualifier = ProtoField.uint8("ARS548.EgoSpeed.ExtendedQualifier", "Extended Qualifier", base.DEC)
    local f_EgoSpeed_LongitudinalSpeed = ProtoField.float("ARS548.EgoSpeed.LongitudinalSpeed", "Longitudinal Speed of Vehicle", base.DEC)
    local f_EgoSpeed_LongitudinalSpeed_STD = ProtoField.float("ARS548.EgoSpeed.LongitudinalSpeed_STD", "Longitudinal Speed Std", base.DEC)

    p_ARS548_EgoSpeed.fields = {
        f_EgoSpeed_Timestamp_Nanoseconds, f_EgoSpeed_Timestamp_Seconds, f_EgoSpeed_Timestamp_SyncStatus, f_EgoSpeed_EventDataQualifier,
        f_EgoSpeed_ExtendedQualifier, f_EgoSpeed_LongitudinalSpeed, f_EgoSpeed_LongitudinalSpeed_STD
    }







-- constants:
centerFrequency = {
    [0] = "Low (76.23)",
    [1] = "Mid (76.48)",
    [2] = "High (76,73)"
    };
countryCode = {
    [1] = "Worldwide（世界通用版）",
    [2] = "Japan（日本专用版/发射功率降低10dB）"
    };
local methodIDs = {
    [0x0141]  = "AccelerationLatralCoG",
    [0x0142]  = "AccelerationLongitudinalCoG",
    [0x0143]  = "VelocityVehicle",
    [0x0145]  = "DrivingDirection",
    [0x0146]  = "YawRate",
    [0x0147]  = "SteeringAnfleFrontAxle",
    [0x0148]  = "CharacteristicSpeed",
    [0x0149]  = "ObjectList (TX)",
    [0x0150]  = "DetectionList (TX)",
    [0x017C]  = "SensorStatus (TX)",
    [0x0186]  = "SensorConfiguration"
    };
plugOrientation = {
    [0] = "PLUG_RIGHT（朝向驾驶员左侧）",
    [1] = "PLUG_LEFT（朝向驾驶员右侧）"
    };
powerSafeStandStill = {
    [0] = "OFF（关闭）",
    [1] = "ON（开启）"
    };
radarStatus = {
    [0] = "STATE_INIT（雷达初始化...）",
    [1] = "STATE_OK（雷达状态正常）",
    [2] = "STATE_INVALID（雷达状态异常）"
    };
vdyStatus = {
    [0] = "VDY OK（本车动态信息输入正常）",
    [1] = "VDY NOTOK（本车动态信息输入超时）"
    };

voltageStatus = {
    [0x00] = "Unknown/Normal voltage（电压正常）",    
	[0x01] = "Current undervoltage（当前低压）",
    [0x02] = "Past undervoltage（之前低压）",
    [0x04] = "Current overvoltage（当前高压）",
    [0x08] = "Past overvoltage（之前高压）"
    };
temperatureStatus = {
    [0x00] = "Unknown/Normal temperature（温度正常）",
	[0x01] = "Current undertemperature（当前低温）",
    [0x02] = "Past undertemperature（之前低温）",
    [0x04] = "Current overtemperature（当前高温）",
    [0x08] = "Past overtemperature（之前高温）"
    };
blockageStatus = {
    [0x00] = "Selftest failed，Blind blockage（堵塞自检失败，致盲性堵塞）",
    [0x01] = "Selftest failed，High blockage（堵塞自检失败，高程度堵塞）",
    [0x02] = "Selftest failed，Mid blockage（堵塞自检失败，中程度堵塞）",
    [0x03] = "Selftest failed，Low blockage（堵塞自检失败，低程度堵塞）",
    [0x04] = "Selftest failed，None blockage（堵塞自检失败，暂未发现堵塞）",
    [0x10] = "Selftest passed，Blind blockage（堵塞自检通过，致盲性堵塞）",
    [0x11] = "Selftest passed，High blockage（堵塞自检通过，高程度堵塞）",
    [0x12] = "Selftest passed，Mid blockage（堵塞自检通过，中程度堵塞）",
    [0x13] = "Selftest passed，Low blockage（堵塞自检通过，低程度堵塞）",
    [0x14] = "Selftest passed，None blockage（堵塞自检通过，暂未发现堵塞）",
    [0x20] = "Selftest ongoing，Blind blockage（堵塞自检中...致盲性堵塞）",
    [0x21] = "Selftest ongoing，High blockage（堵塞自检中...高程度堵塞）",
    [0x22] = "Selftest ongoing，Mid blockage（堵塞自检中...中程度堵塞）",
    [0x23] = "Selftest ongoing，Low blockage（堵塞自检中...低程度堵塞）",
    [0x24] = "Selftest ongoing，None blockage（堵塞自检中...暂未发现堵塞）"
    };








    -- SensorStatus
    local p_ARS548_SensorStatus = Proto("ARS548.SensorStatus", "ARS548.SensorStatus")

    local f_SensorStatus_Timestamp_Nanoseconds = ProtoField.uint32("ARS548.SensorStatus.Timestamp_Nanoseconds", "Timestamp Nanoseconds [ns]", base.DEC)
    local f_SensorStatus_Timestamp_Seconds = ProtoField.uint32("ARS548.SensorStatus.Timestamp_Seconds", "Timestamp Seconds [s]", base.DEC)
    local f_SensorStatus_Timestamp_SyncStatus = ProtoField.uint8("ARS548.SensorStatus.Timestamp_SyncStatus", "Timestamp Sync Status", base.DEC,{[1] = "SYNC_OK（同步正常）",[2] = "SYNC_NEVERSYNC（未同步过）",[3] = "SYNC_LOST（同步终止）"})
    local f_SensorStatus_SWVersion = ProtoField.uint24("ARS548.SensorStatus.SWVersion", "Software Version", base.HEX) 
    local f_SensorStatus_Longitudinal = ProtoField.float("ARS548.SensorStatus.Longitudinal", "Longitudinal sensor position (AUTOSAR) [m]", base.DEC)
    local f_SensorStatus_Lateral = ProtoField.float("ARS548.SensorStatus.Lateral", "Lateral sensor position (AUTOSAR) [m]", base.DEC)
    local f_SensorStatus_Vertical = ProtoField.float("ARS548.SensorStatus.Vertical", "Vertical sensor position (AUTOSAR) [m]", base.DEC)
    local f_SensorStatus_Yaw = ProtoField.float("ARS548.SensorStatus.Yaw", "Sensor yaw angle (AUTOSAR) [rad]", base.DEC)
    local f_SensorStatus_Pitch = ProtoField.float("ARS548.SensorStatus.Pitch", "Sensor pitch angle (AUTOSAR) [rad]", base.DEC)
    local f_SensorStatus_PlugOrientation = ProtoField.uint8("ARS548.SensorStatus.PlugOrientation", "Orientation of plug", base.DEC, plugOrientation)
    local f_SensorStatus_Length = ProtoField.float("ARS548.SensorStatus.Length", "Vehicle length [m]", base.DEC)
    local f_SensorStatus_Width = ProtoField.float("ARS548.SensorStatus.Width", "Vehicle width [m]", base.DEC)
    local f_SensorStatus_Height = ProtoField.float("ARS548.SensorStatus.Height", "Vehicle height [m]", base.DEC)
    local f_SensorStatus_Wheelbase = ProtoField.float("ARS548.SensorStatus.Wheelbase", "Vehicle wheelbase [m]", base.DEC)
    local f_SensorStatus_MaximumDistance = ProtoField.uint16("ARS548.SensorStatus.MaximumDistance", "Maximum detection distance [m]", base.DEC)
    local f_SensorStatus_FrequencySlot = ProtoField.uint8("ARS548.SensorStatus.FrequencySlot", "Center frequency [GHz]", base.DEC, centerFrequency)
    local f_SensorStatus_CycleTime = ProtoField.uint8("ARS548.SensorStatus.CycleTime", "Cycle time [ms]", base.DEC)
    local f_SensorStatus_TimeSlot = ProtoField.uint8("ARS548.SensorStatus.TimeSlot", "Cycle offset [ms]", base.DEC)
    local f_SensorStatus_HCC = ProtoField.uint8("ARS548.SensorStatus.HCC", "Country code", base.DEC, countryCode)
    local f_SensorStatus_Powersave_Standstill = ProtoField.uint8("ARS548.SensorStatus.Powersave_Standstill", "Power saving in standstill", base.DEC, powerSafeStandStill)
    local f_SensorStatus_SensorIPAddress_0 = ProtoField.ipv4("ARS548.SensorStatus.SensorIPAddress_0", "Sensor IP address", base.DEC)
    local f_SensorStatus_SensorIPAddress_1 = ProtoField.ipv4("ARS548.SensorStatus.SensorIPAddress_1", "Reserved", base.DEC)
    local f_SensorStatus_Configuration_counter = ProtoField.uint8("ARS548.SensorStatus.Configuration_counter", "Counter that counts up if new configuration has been received and accepted", base.DEC)
    local f_SensorStatus_Status_LongitudinalVelocity = ProtoField.uint8("ARS548.SensorStatus.Status_LongitudinalVelocity", "Signals if current VDY is OK or timed out", base.DEC, vdyStatus)
    local f_SensorStatus_Status_LongitudinalAcceleration = ProtoField.uint8("ARS548.SensorStatus.Status_LongitudinalAcceleration", "VDY Longitudinal Acceleration Signal Status", base.DEC, vdyStatus)
    local f_SensorStatus_Status_LateralAcceleration = ProtoField.uint8("ARS548.SensorStatus.Status_LateralAcceleration", "VDY Lateral Acceleration Signal Status", base.DEC, vdyStatus)
    local f_SensorStatus_Status_YawRate = ProtoField.uint8("ARS548.SensorStatus.Status_YawRate", "VDY Yaw Rate Signal Status", base.DEC, vdyStatus)
    local f_SensorStatus_Status_SteeringAngle = ProtoField.uint8("ARS548.SensorStatus.Status_SteeringAngle", "VDY Steering Angle Signal Status", base.DEC, vdyStatus)
    local f_SensorStatus_Status_DrivingDirection = ProtoField.uint8("ARS548.SensorStatus.Status_DrivingDirection", "VDY Driving Direction Signal Status", base.DEC, vdyStatus)
    local f_SensorStatus_Status_CharacteristicSpeed = ProtoField.uint8("ARS548.SensorStatus.Status_CharacteristicSpeed", "VDY Characteristic Speed Signal Status（暂未使用，可总输入0 kmph）", base.DEC, vdyStatus)
    local f_SensorStatus_Status_Radar = ProtoField.uint8("ARS548.SensorStatus.Status_Radar", "Radar Status（雷达状态信息）", base.DEC, radarStatus)
    local f_SensorStatus_Status_VoltageStatus = ProtoField.uint8("ARS548.SensorStatus.Status_VoltageStatus", "Voltage Status", base.HEX, voltageStatus)
    local f_SensorStatus_Status_TemperatureStatus = ProtoField.uint8("ARS548.SensorStatus.Status_TemperatureStatus", "Temperature Status", base.HEX, temperatureStatus)
    local f_SensorStatus_Status_BlockageStatus = ProtoField.uint8("ARS548.SensorStatus.Status_BlockageStatus", "Blockage Status", base.HEX, blockageStatus)





    
    p_ARS548_SensorStatus.fields = {
        f_SensorStatus_Timestamp_Nanoseconds, f_SensorStatus_Timestamp_Seconds, f_SensorStatus_Timestamp_SyncStatus, f_SensorStatus_SWVersion,
        f_SensorStatus_Longitudinal, f_SensorStatus_Lateral, f_SensorStatus_Vertical, f_SensorStatus_Yaw, f_SensorStatus_Pitch,
        f_SensorStatus_PlugOrientation, f_SensorStatus_Length, f_SensorStatus_Width, f_SensorStatus_Height, f_SensorStatus_Wheelbase, f_SensorStatus_MaximumDistance,
        f_SensorStatus_FrequencySlot, f_SensorStatus_CycleTime, f_SensorStatus_TimeSlot, f_SensorStatus_HCC, f_SensorStatus_Powersave_Standstill,
        f_SensorStatus_SensorIPAddress_0, f_SensorStatus_SensorIPAddress_1, f_SensorStatus_Configuration_counter, f_SensorStatus_Status_LongitudinalVelocity,
        f_SensorStatus_Status_LongitudinalAcceleration, f_SensorStatus_Status_LateralAcceleration, f_SensorStatus_Status_YawRate, f_SensorStatus_Status_SteeringAngle,
        f_SensorStatus_Status_DrivingDirection, f_SensorStatus_Status_CharacteristicSpeed, f_SensorStatus_Status_Radar,
        f_SensorStatus_Status_VoltageStatus, f_SensorStatus_Status_TemperatureStatus, f_SensorStatus_Status_BlockageStatus
    }

    -- SensorConfiguration
    SensorConfiguration = {
        proto = Proto("ARS548.SensorConfiguration", "ARS548.SensorConfiguration"),

        Longitudinal = ProtoField.float("ARS548.SensorConfiguration.Longitudinal", "Longitudinal sensor position (AUTOSAR)", base.DEC),
        Lateral = ProtoField.float("ARS548.SensorConfiguration.Lateral", "Lateral sensor position (AUTOSAR)", base.DEC),
        Vertical = ProtoField.float("ARS548.SensorConfiguration.Vertical", "Vertical sensor position (AUTOSAR)", base.DEC),
        Yaw = ProtoField.float("ARS548.SensorConfiguration.Yaw", "Sensor yaw angle (AUTOSAR)", base.DEC),
        Pitch = ProtoField.float("ARS548.SensorConfiguration.Pitch", "Sensor pitch angle (AUTOSAR)", base.DEC),
        PlugOrientation = ProtoField.uint8("ARS548.SensorConfiguration.PlugOrientation", "Orientation of plug", base.DEC, plugOrientation),
        Length = ProtoField.float("ARS548.SensorConfiguration.Length", "Vehicle length", base.DEC),
        Width = ProtoField.float("ARS548.SensorConfiguration.Width", "Vehicle width", base.DEC),
        Height = ProtoField.float("ARS548.SensorConfiguration.Height", "Vehicle height", base.DEC),
        Wheelbase = ProtoField.float("ARS548.SensorConfiguration.Wheelbase", "Vehicle wheelbase", base.DEC),
        MaximumDistance = ProtoField.uint16("ARS548.SensorConfiguration.MaximumDistance", "Maximum detection distance", base.DEC),
        FrequencySlot = ProtoField.uint8("ARS548.SensorConfiguration.FrequencySlot", "Center frequency (if MaximumDistance < 190 m only Mid can be selected)", base.DEC, centerFrequency),
        CycleTime = ProtoField.uint8("ARS548.SensorConfiguration.CycleTime", "Cycle time", base.DEC),
        TimeSlot = ProtoField.uint8("ARS548.SensorConfiguration.TimeSlot", "Cycle offset", base.DEC),
        HCC = ProtoField.uint8("ARS548.SensorConfiguration.HCC", "Country code", base.DEC, countryCode),
        Powersave_Standstill = ProtoField.uint8("ARS548.SensorConfiguration.Powersave_Standstill", "Power saving in standstill", base.DEC, powerSafeStandStill),
        SensorIPAddress_0 = ProtoField.ipv4("ARS548.SensorConfiguration.SensorIPAddress_0", "Sensor IP address", base.DEC),
        SensorIPAddress_1 = ProtoField.ipv4("ARS548.SensorConfiguration.SensorIPAddress_1", "Reserved", base.DEC),
        NewSensorMounting = ProtoField.uint8("ARS548.SensorConfiguration.NewSensorMounting", "Flag if new sensor mounting position shall be configured", base.DEC),
        NewVehicleParameters = ProtoField.uint8("ARS548.SensorConfiguration.NewVehicleParameters", "Flag if new vehicle parameters position shall be configured", base.DEC),
        NewRadarParameters = ProtoField.uint8("ARS548.SensorConfiguration.NewRadarParameters", "Flag if new radar parameter shall be configured", base.DEC),
        NewNetworkConfiguration = ProtoField.uint8("ARS548.SensorConfiguration.NewNetworkConfiguration", "Flag if new IP address shall be configured", base.DEC),
    }

    p_ARS548_SensorConfiguration = SensorConfiguration.proto
    p_ARS548_SensorConfiguration.fields = {
        SensorConfiguration.Longitudinal, SensorConfiguration.Lateral, SensorConfiguration.Vertical, SensorConfiguration.Yaw,
        SensorConfiguration.Pitch, SensorConfiguration.PlugOrientation, SensorConfiguration.Length, SensorConfiguration.Width,
        SensorConfiguration.Height, SensorConfiguration.Wheelbase, SensorConfiguration.MaximumDistance, SensorConfiguration.FrequencySlot,
        SensorConfiguration.CycleTime, SensorConfiguration.TimeSlot, SensorConfiguration.HCC, SensorConfiguration.Powersave_Standstill,
        SensorConfiguration.SensorIPAddress_0, SensorConfiguration.SensorIPAddress_1, SensorConfiguration.NewSensorMounting,
        SensorConfiguration.NewVehicleParameters, SensorConfiguration.NewRadarParameters, SensorConfiguration.NewNetworkConfiguration
    }


    MESSAGE_ID_DETECTION_LIST = 336
    MESSAGE_ID_OBJECT_LIST = 329
    MESSAGE_ID_LANDMARKS = 337
    MESSAGE_ID_FIELD_OF_VIEW = 338
    MESSAGE_ID_EGO_SPEED = 339
    MESSAGE_ID_SENSOR_STATUS = 380
    MESSAGE_ID_SENSOR_CONFIGURATION = 390

    MESSAGE_ID_MAP = {
        [MESSAGE_ID_DETECTION_LIST] = "DetectionList",
        [MESSAGE_ID_OBJECT_LIST] = "ObjectList",
        [MESSAGE_ID_LANDMARKS] = "Landmarks",
        [MESSAGE_ID_FIELD_OF_VIEW] = "FieldOfView",
        [MESSAGE_ID_EGO_SPEED] = "EgoSpeed",
        [MESSAGE_ID_SENSOR_STATUS] = "SensorStatus",
        [MESSAGE_ID_SENSOR_CONFIGURATION] = "SensorConfiguration",
    }

    local function ARS_dissector(buf, pkt, root)
        local buf_len = buf:len();
        --先检查报文长度，太短的不是我的协议
        if buf_len < 16 then return false end

        -- SOME/IP  Header (16 Bytes)
        -- 分为 Header 1st Part 和 Header 2nd Part，根据不同的 MessageID，后者不一定有。
        SOME_IP_HEADER_OFFSET = 0
        SOME_IP_HEADER_1ST_PART_SIZE = 8
        SOME_IP_HEADER_2ND_PART_SIZE = 8

        --验证一下serviceID这个字段是不是0x00,如果不是的话，认为不是我要解析的packet
        local v_serviceID = buf(0, 2)
        if (v_serviceID:uint() ~= 0) then
            return false
        end

        --验证methodID，如果不在 MESSAGE_ID_MAP 中就是无法识别的数据。
        local v_methodID = buf(2, 2)
        local messageTypeName = nil
        for key, val in pairs(MESSAGE_ID_MAP) do
            if (v_methodID:uint() == key) then
                messageTypeName = val
                break
            end
        end

        if messageTypeName == nil then
            return false
        end

        -- 根据 methodID 确认是否有 Header 2nd Part，这个影响到 some_ip_payload_offset 的计算。
        local some_ip_header_size
        local some_ip_header_2nd_exists
        if v_methodID:uint() == MESSAGE_ID_DETECTION_LIST or v_methodID:uint() == MESSAGE_ID_OBJECT_LIST then
            -- 目前仅 DetectionList 和 ObjectList 包有 Header 2nd Part
            some_ip_header_size = SOME_IP_HEADER_1ST_PART_SIZE + SOME_IP_HEADER_2ND_PART_SIZE
            some_ip_header_2nd_exists = true
        else
            some_ip_header_size = SOME_IP_HEADER_1ST_PART_SIZE
            some_ip_header_2nd_exists = false
        end
        local some_ip_payload_offset = SOME_IP_HEADER_OFFSET + some_ip_header_size
        local some_ip_payload_size = buf_len - some_ip_header_size

        --取出其他字段的值
        local v_length = buf(4, 4)
        local v_clientID = buf(8, 2)
        local v_sessionID = buf(10, 2)
        local v_protocolVersion = buf(12, 1)
        local v_interfaceVersion = buf(13, 1)
        local v_messageType = buf(14, 1)
        local v_returnCode = buf(15, 1)

        --现在知道是我的协议了，放心大胆添加Packet Details
        local t = root:add(p_ARS548, buf(SOME_IP_HEADER_OFFSET, some_ip_header_size), nil, "(" .. some_ip_header_size .. " bytes) - " .. messageTypeName)
        --在Packet List窗格的Protocol列可以展示出协议的名称
        pkt.cols.protocol = string.format("ARS548 (%s)", messageTypeName)
        --这里是把对应的字段的值填写正确，只有t:add过的才会显示在Packet Details信息里。所以在之前定义fields的时候要把所有可能出现的都写上，但是实际解析的时候，如果某些字段没出现，就不要在这里add
        t:add(SomeIpHeader.fields.serviceID, v_serviceID)
        t:add(SomeIpHeader.fields.methodID, v_methodID, v_methodID:uint()):append_text(" (" .. messageTypeName .. ")")
        t:add(SomeIpHeader.fields.length, v_length)
        if some_ip_header_2nd_exists then
            t:add(SomeIpHeader.fields.clientID, v_clientID)
            t:add(SomeIpHeader.fields.sessionID, v_sessionID)
            t:add(SomeIpHeader.fields.protocolVersion, v_protocolVersion)
            t:add(SomeIpHeader.fields.interfaceVersion, v_interfaceVersion)
            t:add(SomeIpHeader.fields.messageType, v_messageType)
            t:add(SomeIpHeader.fields.returnCode, v_returnCode)
        end

        -- 后面是 SomeIP Payload 部分，定义一个 p_ARS548_Payload 协议来继续解析。
        t = root:add(p_ARS548_Payload, buf(some_ip_payload_offset, some_ip_payload_size), nil, "(" .. some_ip_payload_size .. " bytes)")

        local function addE2eP07Header(offset)
            E2E_P07_SIZE = 20
            local t_e2eP07Header = t:add(p_ARS548_E2E_P07_Header, buf(offset, E2E_P07_SIZE), nil, "(" .. E2E_P07_SIZE .. " bytes)")
            local v_CRC = buf(offset, 8)
            local v_len = buf(offset + 8, 4)
            local v_SQC = buf(offset + 8 + 4, 4)
            local v_dataID = buf(offset + 8 + 4 + 4, 4)
            t_e2eP07Header:add(f_CRC, v_CRC)
            t_e2eP07Header:add(f_len, v_len)
            t_e2eP07Header:add(f_SQC, v_SQC)
            t_e2eP07Header:add(f_dataID, v_dataID)
            return E2E_P07_SIZE
        end

        local function addEgoSpeed(offset)
            EGO_SPEED_SIZE = 22
            local t_EgoSpeed = t:add(p_ARS548_EgoSpeed, buf(offset, EGO_SPEED_SIZE), nil, "(" .. EGO_SPEED_SIZE .. " bytes)")

            local v_EgoSpeed_Timestamp_Nanoseconds = buf(offset + 0, 4)
            local v_EgoSpeed_Timestamp_Seconds = buf(offset + 4, 4)
            local v_EgoSpeed_Timestamp_SyncStatus = buf(offset + 8, 1)
            local v_EgoSpeed_EventDataQualifier = buf(offset + 9, 4)
            local v_EgoSpeed_ExtendedQualifier = buf(offset + 13, 1)
            local v_EgoSpeed_LongitudinalSpeed = buf(offset + 14, 4)
            local v_EgoSpeed_LongitudinalSpeed_STD = buf(offset + 18, 4)

            t_EgoSpeed:add(f_EgoSpeed_Timestamp_Nanoseconds, v_EgoSpeed_Timestamp_Nanoseconds)
            t_EgoSpeed:add(f_EgoSpeed_Timestamp_Seconds, v_EgoSpeed_Timestamp_Seconds)
            t_EgoSpeed:add(f_EgoSpeed_Timestamp_SyncStatus, v_EgoSpeed_Timestamp_SyncStatus)
            t_EgoSpeed:add(f_EgoSpeed_EventDataQualifier, v_EgoSpeed_EventDataQualifier)
            t_EgoSpeed:add(f_EgoSpeed_ExtendedQualifier, v_EgoSpeed_ExtendedQualifier)
            t_EgoSpeed:add(f_EgoSpeed_LongitudinalSpeed, v_EgoSpeed_LongitudinalSpeed)
            t_EgoSpeed:add(f_EgoSpeed_LongitudinalSpeed_STD, v_EgoSpeed_LongitudinalSpeed_STD)

            return EGO_SPEED_SIZE
        end

        local function addSensorStatus(offset)
            SENSOR_STATUS_SIZE = 76
            local t_SensorStatus = t:add(p_ARS548_SensorStatus, buf(offset, SENSOR_STATUS_SIZE), nil, "(" .. SENSOR_STATUS_SIZE .. " bytes)")

            local v_SensorStatus_Timestamp_Nanoseconds = buf(offset + 0, 4)
            local v_SensorStatus_Timestamp_Seconds = buf(offset + 4, 4)
            local v_SensorStatus_Timestamp_SyncStatus = buf(offset + 8, 1)
            local v_SensorStatus_SWVersion = buf(offset + 9, 3)
            local v_SensorStatus_Longitudinal = buf(offset + 12, 4)
            local v_SensorStatus_Lateral = buf(offset + 16, 4)
            local v_SensorStatus_Vertical = buf(offset + 20, 4)
            local v_SensorStatus_Yaw = buf(offset + 24, 4)
            local v_SensorStatus_Pitch = buf(offset + 28, 4)
            local v_SensorStatus_PlugOrientation = buf(offset + 32, 1)
            local v_SensorStatus_Length = buf(offset + 33, 4)
            local v_SensorStatus_Width = buf(offset + 37, 4)
            local v_SensorStatus_Height = buf(offset + 41, 4)
            local v_SensorStatus_Wheelbase = buf(offset + 45, 4)
            local v_SensorStatus_MaximumDistance = buf(offset + 49, 2)
            local v_SensorStatus_FrequencySlot = buf(offset + 51, 1)
            local v_SensorStatus_CycleTime = buf(offset + 52, 1)
            local v_SensorStatus_TimeSlot = buf(offset + 53, 1)
            local v_SensorStatus_HCC = buf(offset + 54, 1)
            local v_SensorStatus_Powersave_Standstill = buf(offset + 55, 1)
            local v_SensorStatus_SensorIPAddress_0 = buf(offset + 56, 4)
            local v_SensorStatus_SensorIPAddress_1 = buf(offset + 60, 4)
            local v_SensorStatus_Configuration_counter = buf(offset + 64, 1)
            local v_SensorStatus_Status_LongitudinalVelocity = buf(offset + 65, 1)
            local v_SensorStatus_Status_LongitudinalAcceleration = buf(offset + 66, 1)
            local v_SensorStatus_Status_LateralAcceleration = buf(offset + 67, 1)
            local v_SensorStatus_Status_YawRate = buf(offset + 68, 1)
            local v_SensorStatus_Status_SteeringAngle = buf(offset + 69, 1)
            local v_SensorStatus_Status_DrivingDirection = buf(offset + 70, 1)
            local v_SensorStatus_Status_CharacteristicSpeed = buf(offset + 71, 1)
            local v_SensorStatus_Status_Radar = buf(offset + 72, 1)
            local v_SensorStatus_Status_VoltageStatus = buf(offset + 73, 1)
            local v_SensorStatus_Status_TemperatureStatus = buf(offset + 74, 1)
            local v_SensorStatus_Status_BlockageStatus = buf(offset + 75, 1)
            offset = offset + SENSOR_STATUS_SIZE

            t_SensorStatus:add(f_SensorStatus_Timestamp_Nanoseconds, v_SensorStatus_Timestamp_Nanoseconds)
            t_SensorStatus:add(f_SensorStatus_Timestamp_Seconds, v_SensorStatus_Timestamp_Seconds)
            t_SensorStatus:add(f_SensorStatus_Timestamp_SyncStatus, v_SensorStatus_Timestamp_SyncStatus)
            t_SensorStatus:add(f_SensorStatus_SWVersion, v_SensorStatus_SWVersion)
            t_SensorStatus:add(f_SensorStatus_Longitudinal, v_SensorStatus_Longitudinal)
            t_SensorStatus:add(f_SensorStatus_Lateral, v_SensorStatus_Lateral)
            t_SensorStatus:add(f_SensorStatus_Vertical, v_SensorStatus_Vertical)
            t_SensorStatus:add(f_SensorStatus_Yaw, v_SensorStatus_Yaw)
            t_SensorStatus:add(f_SensorStatus_Pitch, v_SensorStatus_Pitch)
            t_SensorStatus:add(f_SensorStatus_PlugOrientation, v_SensorStatus_PlugOrientation)
            t_SensorStatus:add(f_SensorStatus_Length, v_SensorStatus_Length)
            t_SensorStatus:add(f_SensorStatus_Width, v_SensorStatus_Width)
            t_SensorStatus:add(f_SensorStatus_Height, v_SensorStatus_Height)
            t_SensorStatus:add(f_SensorStatus_Wheelbase, v_SensorStatus_Wheelbase)
            t_SensorStatus:add(f_SensorStatus_MaximumDistance, v_SensorStatus_MaximumDistance)
            t_SensorStatus:add(f_SensorStatus_FrequencySlot, v_SensorStatus_FrequencySlot)
            t_SensorStatus:add(f_SensorStatus_CycleTime, v_SensorStatus_CycleTime)
            t_SensorStatus:add(f_SensorStatus_TimeSlot, v_SensorStatus_TimeSlot)
            t_SensorStatus:add(f_SensorStatus_HCC, v_SensorStatus_HCC)
            t_SensorStatus:add(f_SensorStatus_Powersave_Standstill, v_SensorStatus_Powersave_Standstill)
            t_SensorStatus:add(f_SensorStatus_SensorIPAddress_0, v_SensorStatus_SensorIPAddress_0)
            t_SensorStatus:add(f_SensorStatus_SensorIPAddress_1, v_SensorStatus_SensorIPAddress_1)
            t_SensorStatus:add(f_SensorStatus_Configuration_counter, v_SensorStatus_Configuration_counter)
            t_SensorStatus:add(f_SensorStatus_Status_LongitudinalVelocity, v_SensorStatus_Status_LongitudinalVelocity)
            t_SensorStatus:add(f_SensorStatus_Status_LongitudinalAcceleration, v_SensorStatus_Status_LongitudinalAcceleration)
            t_SensorStatus:add(f_SensorStatus_Status_LateralAcceleration, v_SensorStatus_Status_LateralAcceleration)
            t_SensorStatus:add(f_SensorStatus_Status_YawRate, v_SensorStatus_Status_YawRate)
            t_SensorStatus:add(f_SensorStatus_Status_SteeringAngle, v_SensorStatus_Status_SteeringAngle)
            t_SensorStatus:add(f_SensorStatus_Status_DrivingDirection, v_SensorStatus_Status_DrivingDirection)
            t_SensorStatus:add(f_SensorStatus_Status_CharacteristicSpeed, v_SensorStatus_Status_CharacteristicSpeed)
            t_SensorStatus:add(f_SensorStatus_Status_Radar, v_SensorStatus_Status_Radar)
            t_SensorStatus:add(f_SensorStatus_Status_VoltageStatus, v_SensorStatus_Status_VoltageStatus)
            t_SensorStatus:add(f_SensorStatus_Status_TemperatureStatus, v_SensorStatus_Status_TemperatureStatus)
            t_SensorStatus:add(f_SensorStatus_Status_BlockageStatus, v_SensorStatus_Status_BlockageStatus)

            return SENSOR_STATUS_SIZE
        end

        local function addSensorConfiguration(offset)
            SENSOR_CONFIGURATION_SIZE = 56
            local t_SensorConfiguration = t:add(p_ARS548_SensorConfiguration, buf(offset, SENSOR_CONFIGURATION_SIZE), nil, "(" .. SENSOR_CONFIGURATION_SIZE .. " bytes)")

            local v_SensorConfiguration_Longitudinal = buf(offset + 0, 4)
            local v_SensorConfiguration_Lateral = buf(offset + 4, 4)
            local v_SensorConfiguration_Vertical = buf(offset + 8, 4)
            local v_SensorConfiguration_Yaw = buf(offset + 12, 4)
            local v_SensorConfiguration_Pitch = buf(offset + 16, 4)
            local v_SensorConfiguration_PlugOrientation = buf(offset + 20, 1)
            local v_SensorConfiguration_Length = buf(offset + 21, 4)
            local v_SensorConfiguration_Width = buf(offset + 25, 4)
            local v_SensorConfiguration_Height = buf(offset + 29, 4)
            local v_SensorConfiguration_Wheelbase = buf(offset + 33, 4)
            local v_SensorConfiguration_MaximumDistance = buf(offset + 37, 2)
            local v_SensorConfiguration_FrequencySlot = buf(offset + 39, 1)
            local v_SensorConfiguration_CycleTime = buf(offset + 40, 1)
            local v_SensorConfiguration_TimeSlot = buf(offset + 41, 1)
            local v_SensorConfiguration_HCC = buf(offset + 42, 1)
            local v_SensorConfiguration_Powersave_Standstill = buf(offset + 43, 1)
            local v_SensorConfiguration_SensorIPAddress_0 = buf(offset + 44, 4)
            local v_SensorConfiguration_SensorIPAddress_1 = buf(offset + 48, 4)
            local v_SensorConfiguration_NewSensorMounting = buf(offset + 52, 1)
            local v_SensorConfiguration_NewVehicleParameters = buf(offset + 53, 1)
            local v_SensorConfiguration_NewRadarParameters = buf(offset + 54, 1)
            local v_SensorConfiguration_NewNetworkConfiguration = buf(offset + 55, 1)
            offset = offset + SENSOR_CONFIGURATION_SIZE

            t_SensorConfiguration:add(SensorConfiguration.Longitudinal, v_SensorConfiguration_Longitudinal)
            t_SensorConfiguration:add(SensorConfiguration.Lateral, v_SensorConfiguration_Lateral)
            t_SensorConfiguration:add(SensorConfiguration.Vertical, v_SensorConfiguration_Vertical)
            t_SensorConfiguration:add(SensorConfiguration.Yaw, v_SensorConfiguration_Yaw)
            t_SensorConfiguration:add(SensorConfiguration.Pitch, v_SensorConfiguration_Pitch)
            t_SensorConfiguration:add(SensorConfiguration.PlugOrientation, v_SensorConfiguration_PlugOrientation)
            t_SensorConfiguration:add(SensorConfiguration.Length, v_SensorConfiguration_Length)
            t_SensorConfiguration:add(SensorConfiguration.Width, v_SensorConfiguration_Width)
            t_SensorConfiguration:add(SensorConfiguration.Height, v_SensorConfiguration_Height)
            t_SensorConfiguration:add(SensorConfiguration.Wheelbase, v_SensorConfiguration_Wheelbase)
            t_SensorConfiguration:add(SensorConfiguration.MaximumDistance, v_SensorConfiguration_MaximumDistance)
            t_SensorConfiguration:add(SensorConfiguration.FrequencySlot, v_SensorConfiguration_FrequencySlot)
            t_SensorConfiguration:add(SensorConfiguration.CycleTime, v_SensorConfiguration_CycleTime)
            t_SensorConfiguration:add(SensorConfiguration.TimeSlot, v_SensorConfiguration_TimeSlot)
            t_SensorConfiguration:add(SensorConfiguration.HCC, v_SensorConfiguration_HCC)
            t_SensorConfiguration:add(SensorConfiguration.Powersave_Standstill, v_SensorConfiguration_Powersave_Standstill)
            t_SensorConfiguration:add(SensorConfiguration.SensorIPAddress_0, v_SensorConfiguration_SensorIPAddress_0)
            t_SensorConfiguration:add(SensorConfiguration.SensorIPAddress_1, v_SensorConfiguration_SensorIPAddress_1)
            t_SensorConfiguration:add(SensorConfiguration.NewSensorMounting, v_SensorConfiguration_NewSensorMounting)
            t_SensorConfiguration:add(SensorConfiguration.NewVehicleParameters, v_SensorConfiguration_NewVehicleParameters)
            t_SensorConfiguration:add(SensorConfiguration.NewRadarParameters, v_SensorConfiguration_NewRadarParameters)
            t_SensorConfiguration:add(SensorConfiguration.NewNetworkConfiguration, v_SensorConfiguration_NewNetworkConfiguration)

            return t_SensorConfiguration
        end

        -- 各 Message 的解析
        if v_methodID:uint() == MESSAGE_ID_DETECTION_LIST then
            DETECTION_SIZE = 44
            MAX_DETECTION_COUNT = 800

            -- offset = 36
            local offset = some_ip_payload_offset + addE2eP07Header(some_ip_payload_offset)

            local v_Timestamp_Nanoseconds = buf(36, 4)
            local v_Timestamp_Seconds = buf(40, 4)
            local v_Timestamp_SyncStatus = buf(44, 1)
            local v_EventDataQualifier = buf(45, 4)
            local v_ExtendedQualifier = buf(49, 1)
            local v_Origin_InvalidFlags = buf(50, 2)
            local v_Origin_Xpos = buf(52, 4)
            local v_Origin_Xstd = buf(56, 4)
            local v_Origin_Ypos = buf(60, 4)
            local v_Origin_Ystd = buf(64, 4)
            local v_Origin_Zpos = buf(68, 4)
            local v_Origin_Zstd = buf(72, 4)
            local v_Origin_Roll = buf(76, 4)
            local v_Origin_Rollstd = buf(80, 4)
            local v_Origin_Pitch = buf(84, 4)
            local v_Origin_Pitchstd = buf(88, 4)
            local v_Origin_Yaw = buf(92, 4)
            local v_Origin_Yawstd = buf(96, 4)
            local v_List_InvalidFlags = buf(100, 1)

            local offset_detection_list_start = 101

            local t_detectionList = t:add(p_ARS548_DetectionList, buf(36, buf_len - 36))
            t_detectionList:add(f_Timestamp_Nanoseconds, v_Timestamp_Nanoseconds)
            t_detectionList:add(f_Timestamp_Seconds, v_Timestamp_Seconds)
            t_detectionList:add(f_Timestamp_SyncStatus, v_Timestamp_SyncStatus)
            t_detectionList:add(f_EventDataQualifier, v_EventDataQualifier)
            t_detectionList:add(f_ExtendedQualifier, v_ExtendedQualifier)
            t_detectionList:add(f_Origin_InvalidFlags, v_Origin_InvalidFlags)
            t_detectionList:add(f_Origin_Xpos, v_Origin_Xpos)
            t_detectionList:add(f_Origin_Xstd, v_Origin_Xstd)
            t_detectionList:add(f_Origin_Ypos, v_Origin_Ypos)
            t_detectionList:add(f_Origin_Ystd, v_Origin_Ystd)
            t_detectionList:add(f_Origin_Zpos, v_Origin_Zpos)
            t_detectionList:add(f_Origin_Zstd, v_Origin_Zstd)
            t_detectionList:add(f_Origin_Roll, v_Origin_Roll)
            t_detectionList:add(f_Origin_Rollstd, v_Origin_Rollstd)
            t_detectionList:add(f_Origin_Pitch, v_Origin_Pitch)
            t_detectionList:add(f_Origin_Pitchstd, v_Origin_Pitchstd)
            t_detectionList:add(f_Origin_Yaw, v_Origin_Yaw)
            t_detectionList:add(f_Origin_Yawstd, v_Origin_Yawstd)
            t_detectionList:add(f_List_InvalidFlags, v_List_InvalidFlags)

            local offset_after_detections = offset_detection_list_start + DETECTION_SIZE * MAX_DETECTION_COUNT
            local v_List_RadVelDomain_Min = buf(offset_after_detections + 0, 4)
            local v_List_RadVelDomain_Max = buf(offset_after_detections + 4, 4)
            local v_List_NumOfDetections = buf(offset_after_detections + 8, 4)
            local v_Aln_AzimuthCorrection = buf(offset_after_detections + 12, 4)
            local v_Aln_ElevationCorrection = buf(offset_after_detections + 16, 4)

            local i = 0
            while (i < MAX_DETECTION_COUNT and i < v_List_NumOfDetections:uint()) do
                offset = offset_detection_list_start + i * DETECTION_SIZE

                local v_f_AzimuthAngle = buf(offset + 0, 4)
                local v_f_AzimuthAngleSTD = buf(offset + 4, 4)
                local v_u_InvalidFlags = buf(offset + 8, 1)
                local v_f_ElevationAngle = buf(offset + 9, 4)
                local v_f_ElevationAngleSTD = buf(offset + 13, 4)
                local v_f_Range = buf(offset + 17, 4)
                local v_f_RangeSTD = buf(offset + 21, 4)
                local v_f_RangeRate = buf(offset + 25, 4)
                local v_f_RangeRateSTD = buf(offset + 29, 4)
                local v_s_RCS = buf(offset + 33, 1)
                local v_u_MeasurementID = buf(offset + 34, 2)
                local v_u_PositivePredictiveValue = buf(offset + 36, 1)
                local v_u_Classification = buf(offset + 37, 1)
                local v_u_MultiTargetProbability = buf(offset + 38, 1)
                local v_u_ObjectID = buf(offset + 39, 2)
                local v_u_AmbiguityFlag = buf(offset + 41, 1)
                local v_u_SortIndex = buf(offset + 42, 2)

                local t_detection = t_detectionList:add(p_ARS548_Detection, buf(offset, DETECTION_SIZE)):append_text(" [" .. (i + 1) .. "]")
                t_detection:add(f_f_AzimuthAngle, v_f_AzimuthAngle)
                t_detection:add(f_f_AzimuthAngleSTD, v_f_AzimuthAngleSTD)
                t_detection:add(f_u_InvalidFlags, v_u_InvalidFlags)
                t_detection:add(f_f_ElevationAngle, v_f_ElevationAngle)
                t_detection:add(f_f_ElevationAngleSTD, v_f_ElevationAngleSTD)
                t_detection:add(f_f_Range, v_f_Range)
                t_detection:add(f_f_RangeSTD, v_f_RangeSTD)
                t_detection:add(f_f_RangeRate, v_f_RangeRate)
                t_detection:add(f_f_RangeRateSTD, v_f_RangeRateSTD)
                t_detection:add(f_s_RCS, v_s_RCS)
                t_detection:add(f_u_MeasurementID, v_u_MeasurementID)
                t_detection:add(f_u_PositivePredictiveValue, v_u_PositivePredictiveValue)
                t_detection:add(f_u_Classification, v_u_Classification)
                t_detection:add(f_u_MultiTargetProbability, v_u_MultiTargetProbability)
                t_detection:add(f_u_ObjectID, v_u_ObjectID)
                t_detection:add(f_u_AmbiguityFlag, v_u_AmbiguityFlag)
                t_detection:add(f_u_SortIndex, v_u_SortIndex)

                i = i + 1
            end

            t_detectionList:add(f_List_RadVelDomain_Min, v_List_RadVelDomain_Min)
            t_detectionList:add(f_List_RadVelDomain_Max, v_List_RadVelDomain_Max)
            t_detectionList:add(f_List_NumOfDetections, v_List_NumOfDetections)
            t_detectionList:add(f_Aln_AzimuthCorrection, v_Aln_AzimuthCorrection)
            t_detectionList:add(f_Aln_ElevationCorrection, v_Aln_ElevationCorrection)

            return true

        elseif v_methodID:uint() == MESSAGE_ID_OBJECT_LIST then
            OBJECT_SIZE = 187
            OBJECT_COUNT_MAX = 50

            -- offset = 36
            local offset = some_ip_payload_offset + addE2eP07Header(some_ip_payload_offset)

            local v_ObjectList_Timestamp_Nanoseconds = buf(offset + 0, 4)
            local v_ObjectList_Timestamp_Seconds = buf(offset + 4, 4)
            local v_ObjectList_Timestamp_SyncStatus = buf(offset + 8, 1)
            local v_ObjectList_EventDataQualifier = buf(offset + 9, 4)
            local v_ObjectList_ExtendedQualifier = buf(offset + 13, 1)
            local v_ObjectList_NumOfObjects = buf(offset + 14, 1)
            offset = offset + 15
            local offset_object_list_start = offset

            local t_objectList = t:add(p_ARS548_ObjectList, buf(36, buf_len - 36))

            t_objectList:add(f_ObjectList_Timestamp_Nanoseconds, v_ObjectList_Timestamp_Nanoseconds)
            t_objectList:add(f_ObjectList_Timestamp_Seconds, v_ObjectList_Timestamp_Seconds)
            t_objectList:add(f_ObjectList_Timestamp_SyncStatus, v_ObjectList_Timestamp_SyncStatus)
            t_objectList:add(f_ObjectList_EventDataQualifier, v_ObjectList_EventDataQualifier)
            t_objectList:add(f_ObjectList_ExtendedQualifier, v_ObjectList_ExtendedQualifier)
            t_objectList:add(f_ObjectList_NumOfObjects, v_ObjectList_NumOfObjects)

            local i = 0
            local object_count = v_ObjectList_NumOfObjects:uint()
            while (i < object_count) do
                offset = offset_object_list_start + i * OBJECT_SIZE

                local v_object_u_StatusSensor = buf(offset + 0, 2)
                local v_object_u_ID = buf(offset + 2, 4)
                local v_object_u_Age = buf(offset + 6, 2)
                local v_object_u_StatusMeasurement = buf(offset + 8, 1)
                local v_object_u_StatusMovement = buf(offset + 9, 1)
                local v_object_u_Position_InvalidFlags = buf(offset + 10, 2)
                local v_object_u_Position_Reference = buf(offset + 12, 1)
                local v_object_u_Position_X = buf(offset + 13, 4)
                local v_object_u_Position_X_STD = buf(offset + 17, 4)
                local v_object_u_Position_Y = buf(offset + 21, 4)
                local v_object_u_Position_Y_STD = buf(offset + 25, 4)
                local v_object_u_Position_Z = buf(offset + 29, 4)
                local v_object_u_Position_Z_STD = buf(offset + 33, 4)
                local v_object_u_Position_CovarianceXY = buf(offset + 37, 4)
                local v_object_u_Position_Orientation = buf(offset + 41, 4)
                local v_object_u_Position_Orientation_STD = buf(offset + 45, 4)
                local v_object_u_Existence_InvalidFlags = buf(offset + 49, 1)
                local v_object_u_Existence_Probability = buf(offset + 50, 4)
                local v_object_u_Existence_PPV = buf(offset + 54, 4)
                local v_object_u_Classification_Car = buf(offset + 58, 1)
                local v_object_u_Classification_Truck = buf(offset + 59, 1)
                local v_object_u_Classification_Motorcycle = buf(offset + 60, 1)
                local v_object_u_Classification_Bicycle = buf(offset + 61, 1)
                local v_object_u_Classification_Pedestrian = buf(offset + 62, 1)
                local v_object_u_Classification_Animal = buf(offset + 63, 1)
                local v_object_u_Classification_Hazard = buf(offset + 64, 1)
                local v_object_u_Classification_Unknown = buf(offset + 65, 1)
                local v_object_u_Classification_Overdrivable = buf(offset + 66, 1)
                local v_object_u_Classification_Underdrivable = buf(offset + 67, 1)
                local v_object_u_Dynamics_AbsVel_InvalidFlags = buf(offset + 68, 1)
                local v_object_f_Dynamics_AbsVel_X = buf(offset + 69, 4)
                local v_object_f_Dynamics_AbsVel_X_STD = buf(offset + 73, 4)
                local v_object_f_Dynamics_AbsVel_Y = buf(offset + 77, 4)
                local v_object_f_Dynamics_AbsVel_Y_STD = buf(offset + 81, 4)
                local v_object_f_Dynamics_AbsVel_CovarianceXY = buf(offset + 85, 4)
                local v_object_u_Dynamics_RelVel_InvalidFlags = buf(offset + 89, 1)
                local v_object_f_Dynamics_RelVel_X = buf(offset + 90, 4)
                local v_object_f_Dynamics_RelVel_X_STD = buf(offset + 94, 4)
                local v_object_f_Dynamics_RelVel_Y = buf(offset + 98, 4)
                local v_object_f_Dynamics_RelVel_Y_STD = buf(offset + 102, 4)
                local v_object_f_Dynamics_RelVel_CovarianceXY = buf(offset + 106, 4)
                local v_object_u_Dynamics_AbsAccel_InvalidFlags = buf(offset + 110, 1)
                local v_object_f_Dynamics_AbsAccel_X = buf(offset + 111, 4)
                local v_object_f_Dynamics_AbsAccel_X_STD = buf(offset + 115, 4)
                local v_object_f_Dynamics_AbsAccel_Y = buf(offset + 119, 4)
                local v_object_f_Dynamics_AbsAccel_Y_STD = buf(offset + 123, 4)
                local v_object_f_Dynamics_AbsAccel_CovarianceXY = buf(offset + 127, 4)
                local v_object_u_Dynamics_RelAccel_InvalidFlags = buf(offset + 131, 1)
                local v_object_f_Dynamics_RelAccel_X = buf(offset + 132, 4)
                local v_object_f_Dynamics_RelAccel_X_STD = buf(offset + 136, 4)
                local v_object_f_Dynamics_RelAccel_Y = buf(offset + 140, 4)
                local v_object_f_Dynamics_RelAccel_Y_STD = buf(offset + 144, 4)
                local v_object_f_Dynamics_RelAccel_CovarianceXY = buf(offset + 148, 4)
                local v_object_u_Dynamics_Orientation_InvalidFlags = buf(offset + 152, 1)
                local v_object_u_Dynamics_Orientation_Rate_Mean = buf(offset + 153, 4)
                local v_object_u_Dynamics_Orientation_Rate_STD = buf(offset + 157, 4)
                local v_object_u_Shape_Length_Status = buf(offset + 161, 4)
                local v_object_u_Shape_Length_Edge_InvalidFlags = buf(offset + 165, 1)
                local v_object_u_Shape_Length_Edge_Mean = buf(offset + 166, 4)
                local v_object_u_Shape_Length_Edge_STD = buf(offset + 170, 4)
                local v_object_u_Shape_Width_Status = buf(offset + 174, 4)
                local v_object_u_Shape_Width_Edge_InvalidFlags = buf(offset + 178, 1)
                local v_object_u_Shape_Width_Edge_Mean = buf(offset + 179, 4)
                local v_object_u_Shape_Width_Edge_STD = buf(offset + 183, 4)

                local t_object = t_objectList:add(p_ARS548_Object, buf(offset, OBJECT_SIZE)):append_text(" [" .. (i + 1) .. "]")
                t_object:add(f_object_u_StatusSensor, v_object_u_StatusSensor)
                t_object:add(f_object_u_ID, v_object_u_ID)
                t_object:add(f_object_u_Age, v_object_u_Age)
                t_object:add(f_object_u_StatusMeasurement, v_object_u_StatusMeasurement)
                t_object:add(f_object_u_StatusMovement, v_object_u_StatusMovement)
                t_object:add(f_object_u_Position_InvalidFlags, v_object_u_Position_InvalidFlags)
                t_object:add(f_object_u_Position_Reference, v_object_u_Position_Reference)
                t_object:add(f_object_u_Position_X, v_object_u_Position_X)
                t_object:add(f_object_u_Position_X_STD, v_object_u_Position_X_STD)
                t_object:add(f_object_u_Position_Y, v_object_u_Position_Y)
                t_object:add(f_object_u_Position_Y_STD, v_object_u_Position_Y_STD)
                t_object:add(f_object_u_Position_Z, v_object_u_Position_Z)
                t_object:add(f_object_u_Position_Z_STD, v_object_u_Position_Z_STD)
                t_object:add(f_object_u_Position_CovarianceXY, v_object_u_Position_CovarianceXY)
                t_object:add(f_object_u_Position_Orientation, v_object_u_Position_Orientation)
                t_object:add(f_object_u_Position_Orientation_STD, v_object_u_Position_Orientation_STD)
                t_object:add(f_object_u_Existence_InvalidFlags, v_object_u_Existence_InvalidFlags)
                t_object:add(f_object_u_Existence_Probability, v_object_u_Existence_Probability)
                t_object:add(f_object_u_Existence_PPV, v_object_u_Existence_PPV)
                t_object:add(f_object_u_Classification_Car, v_object_u_Classification_Car)
                t_object:add(f_object_u_Classification_Truck, v_object_u_Classification_Truck)
                t_object:add(f_object_u_Classification_Motorcycle, v_object_u_Classification_Motorcycle)
                t_object:add(f_object_u_Classification_Bicycle, v_object_u_Classification_Bicycle)
                t_object:add(f_object_u_Classification_Pedestrian, v_object_u_Classification_Pedestrian)
                t_object:add(f_object_u_Classification_Animal, v_object_u_Classification_Animal)
                t_object:add(f_object_u_Classification_Hazard, v_object_u_Classification_Hazard)
                t_object:add(f_object_u_Classification_Unknown, v_object_u_Classification_Unknown)
                t_object:add(f_object_u_Classification_Overdrivable, v_object_u_Classification_Overdrivable)
                t_object:add(f_object_u_Classification_Underdrivable, v_object_u_Classification_Underdrivable)
                t_object:add(f_object_u_Dynamics_AbsVel_InvalidFlags, v_object_u_Dynamics_AbsVel_InvalidFlags)
                t_object:add(f_object_f_Dynamics_AbsVel_X, v_object_f_Dynamics_AbsVel_X)
                t_object:add(f_object_f_Dynamics_AbsVel_X_STD, v_object_f_Dynamics_AbsVel_X_STD)
                t_object:add(f_object_f_Dynamics_AbsVel_Y, v_object_f_Dynamics_AbsVel_Y)
                t_object:add(f_object_f_Dynamics_AbsVel_Y_STD, v_object_f_Dynamics_AbsVel_Y_STD)
                t_object:add(f_object_f_Dynamics_AbsVel_CovarianceXY, v_object_f_Dynamics_AbsVel_CovarianceXY)
                t_object:add(f_object_u_Dynamics_RelVel_InvalidFlags, v_object_u_Dynamics_RelVel_InvalidFlags)
                t_object:add(f_object_f_Dynamics_RelVel_X, v_object_f_Dynamics_RelVel_X)
                t_object:add(f_object_f_Dynamics_RelVel_X_STD, v_object_f_Dynamics_RelVel_X_STD)
                t_object:add(f_object_f_Dynamics_RelVel_Y, v_object_f_Dynamics_RelVel_Y)
                t_object:add(f_object_f_Dynamics_RelVel_Y_STD, v_object_f_Dynamics_RelVel_Y_STD)
                t_object:add(f_object_f_Dynamics_RelVel_CovarianceXY, v_object_f_Dynamics_RelVel_CovarianceXY)
                t_object:add(f_object_u_Dynamics_AbsAccel_InvalidFlags, v_object_u_Dynamics_AbsAccel_InvalidFlags)
                t_object:add(f_object_f_Dynamics_AbsAccel_X, v_object_f_Dynamics_AbsAccel_X)
                t_object:add(f_object_f_Dynamics_AbsAccel_X_STD, v_object_f_Dynamics_AbsAccel_X_STD)
                t_object:add(f_object_f_Dynamics_AbsAccel_Y, v_object_f_Dynamics_AbsAccel_Y)
                t_object:add(f_object_f_Dynamics_AbsAccel_Y_STD, v_object_f_Dynamics_AbsAccel_Y_STD)
                t_object:add(f_object_f_Dynamics_AbsAccel_CovarianceXY, v_object_f_Dynamics_AbsAccel_CovarianceXY)
                t_object:add(f_object_u_Dynamics_RelAccel_InvalidFlags, v_object_u_Dynamics_RelAccel_InvalidFlags)
                t_object:add(f_object_f_Dynamics_RelAccel_X, v_object_f_Dynamics_RelAccel_X)
                t_object:add(f_object_f_Dynamics_RelAccel_X_STD, v_object_f_Dynamics_RelAccel_X_STD)
                t_object:add(f_object_f_Dynamics_RelAccel_Y, v_object_f_Dynamics_RelAccel_Y)
                t_object:add(f_object_f_Dynamics_RelAccel_Y_STD, v_object_f_Dynamics_RelAccel_Y_STD)
                t_object:add(f_object_f_Dynamics_RelAccel_CovarianceXY, v_object_f_Dynamics_RelAccel_CovarianceXY)
                t_object:add(f_object_u_Dynamics_Orientation_InvalidFlags, v_object_u_Dynamics_Orientation_InvalidFlags)
                t_object:add(f_object_u_Dynamics_Orientation_Rate_Mean, v_object_u_Dynamics_Orientation_Rate_Mean)
                t_object:add(f_object_u_Dynamics_Orientation_Rate_STD, v_object_u_Dynamics_Orientation_Rate_STD)
                t_object:add(f_object_u_Shape_Length_Status, v_object_u_Shape_Length_Status)
                t_object:add(f_object_u_Shape_Length_Edge_InvalidFlags, v_object_u_Shape_Length_Edge_InvalidFlags)
                t_object:add(f_object_u_Shape_Length_Edge_Mean, v_object_u_Shape_Length_Edge_Mean)
                t_object:add(f_object_u_Shape_Length_Edge_STD, v_object_u_Shape_Length_Edge_STD)
                t_object:add(f_object_u_Shape_Width_Status, v_object_u_Shape_Width_Status)
                t_object:add(f_object_u_Shape_Width_Edge_InvalidFlags, v_object_u_Shape_Width_Edge_InvalidFlags)
                t_object:add(f_object_u_Shape_Width_Edge_Mean, v_object_u_Shape_Width_Edge_Mean)
                t_object:add(f_object_u_Shape_Width_Edge_STD, v_object_u_Shape_Width_Edge_STD)

                i = i + 1
            end

            return true;

        elseif v_methodID:uint() == MESSAGE_ID_LANDMARKS then

            local offset = some_ip_payload_offset
            local v_Landmarks_EventDataQualifier = buf(offset + 0, 4)
            local v_Landmarks_ExtendedQualifier = buf(offset + 4, 1)
            local v_Landmarks_Timestamp_Nanoseconds = buf(offset + 5, 4)
            local v_Landmarks_Timestamp_Seconds = buf(offset + 9, 4)
            local v_Landmarks_Timestamp_SyncStatus = buf(offset + 13, 1)
            local v_Landmarks_InvalidFlags = buf(offset + 14, 1)
            local v_Landmarks_MainHypothesis_RoadConfidence = buf(offset + 15, 4)
            local v_Landmarks_MainHypothesis_LeftLateralOffset = buf(offset + 19, 4)
            local v_Landmarks_MainHypothesis_RightLateralOffset = buf(offset + 23, 4)
            local v_Landmarks_MainHypothesis_HeadingAngle = buf(offset + 27, 4)
            local v_Landmarks_MainHypothesis_Curvature = buf(offset + 31, 4)
            local v_Landmarks_MainHypothesis_CurvatureGradient = buf(offset + 35, 4)
            local v_Landmarks_MainHypothesis_TransitionPoint = buf(offset + 39, 4)
            local v_Landmarks_MainHypothesis_SecondCurvatureGradient = buf(offset + 43, 4)
            local v_Landmarks_MainHypothesis_LeftDataSupportedRanges = buf(offset + 47, 4)
            local v_Landmarks_MainHypothesis_RightDataSupportedRanges = buf(offset + 51, 4)
            local v_Landmarks_MainHypothesis_LeftRangeMax = buf(offset + 55, 4)
            local v_Landmarks_MainHypothesis_RightRangeMax = buf(offset + 59, 4)
            local v_Landmarks_SecondHypothesis_RoadConfidence = buf(offset + 63, 4)
            local v_Landmarks_SecondHypothesis_HeadingAngle = buf(offset + 67, 4)
            local v_Landmarks_SecondHypothesis_Curvature = buf(offset + 71, 4)
            local v_Landmarks_SecondHypothesis_CurvatureGradient = buf(offset + 75, 4)
            local v_Landmarks_SecondHypothesis_LeftRangeMax = buf(offset + 79, 4)
            local v_Landmarks_SecondHypothesis_RightRangeMax = buf(offset + 83, 4)
            local v_Landmarks_LaneMatrix_LeftLanes = buf(offset + 87, 1)
            local v_Landmarks_LaneMatrix_RightLanes = buf(offset + 88, 1)
            local v_Landmarks_DistanceToBorder_Left = buf(offset + 89, 4)
            local v_Landmarks_DistanceToBorder_Right = buf(offset + 93, 4)
            local v_Landmarks_Tunnel_InvalidFlags = buf(offset + 97, 1)
            local v_Landmarks_Tunnel_Distance = buf(offset + 98, 4)
            local v_Landmarks_Tunnel_ExistanceProbability = buf(offset + 102, 4)
            local size = 106

            local t_Landmarks = t:add(p_ARS548_Landmarks, buf(offset, size), nil, "(" .. size .. " bytes)")
            t_Landmarks:add(f_Landmarks_EventDataQualifier, v_Landmarks_EventDataQualifier)
            t_Landmarks:add(f_Landmarks_ExtendedQualifier, v_Landmarks_ExtendedQualifier)
            t_Landmarks:add(f_Landmarks_Timestamp_Nanoseconds, v_Landmarks_Timestamp_Nanoseconds)
            t_Landmarks:add(f_Landmarks_Timestamp_Seconds, v_Landmarks_Timestamp_Seconds)
            t_Landmarks:add(f_Landmarks_Timestamp_SyncStatus, v_Landmarks_Timestamp_SyncStatus)
            t_Landmarks:add(f_Landmarks_InvalidFlags, v_Landmarks_InvalidFlags)
            t_Landmarks:add(f_Landmarks_MainHypothesis_RoadConfidence, v_Landmarks_MainHypothesis_RoadConfidence)
            t_Landmarks:add(f_Landmarks_MainHypothesis_LeftLateralOffset, v_Landmarks_MainHypothesis_LeftLateralOffset)
            t_Landmarks:add(f_Landmarks_MainHypothesis_RightLateralOffset, v_Landmarks_MainHypothesis_RightLateralOffset)
            t_Landmarks:add(f_Landmarks_MainHypothesis_HeadingAngle, v_Landmarks_MainHypothesis_HeadingAngle)
            t_Landmarks:add(f_Landmarks_MainHypothesis_Curvature, v_Landmarks_MainHypothesis_Curvature)
            t_Landmarks:add(f_Landmarks_MainHypothesis_CurvatureGradient, v_Landmarks_MainHypothesis_CurvatureGradient)
            t_Landmarks:add(f_Landmarks_MainHypothesis_TransitionPoint, v_Landmarks_MainHypothesis_TransitionPoint)
            t_Landmarks:add(f_Landmarks_MainHypothesis_SecondCurvatureGradient, v_Landmarks_MainHypothesis_SecondCurvatureGradient)
            t_Landmarks:add(f_Landmarks_MainHypothesis_LeftDataSupportedRanges, v_Landmarks_MainHypothesis_LeftDataSupportedRanges)
            t_Landmarks:add(f_Landmarks_MainHypothesis_RightDataSupportedRanges, v_Landmarks_MainHypothesis_RightDataSupportedRanges)
            t_Landmarks:add(f_Landmarks_MainHypothesis_LeftRangeMax, v_Landmarks_MainHypothesis_LeftRangeMax)
            t_Landmarks:add(f_Landmarks_MainHypothesis_RightRangeMax, v_Landmarks_MainHypothesis_RightRangeMax)
            t_Landmarks:add(f_Landmarks_SecondHypothesis_RoadConfidence, v_Landmarks_SecondHypothesis_RoadConfidence)
            t_Landmarks:add(f_Landmarks_SecondHypothesis_HeadingAngle, v_Landmarks_SecondHypothesis_HeadingAngle)
            t_Landmarks:add(f_Landmarks_SecondHypothesis_Curvature, v_Landmarks_SecondHypothesis_Curvature)
            t_Landmarks:add(f_Landmarks_SecondHypothesis_CurvatureGradient, v_Landmarks_SecondHypothesis_CurvatureGradient)
            t_Landmarks:add(f_Landmarks_SecondHypothesis_LeftRangeMax, v_Landmarks_SecondHypothesis_LeftRangeMax)
            t_Landmarks:add(f_Landmarks_SecondHypothesis_RightRangeMax, v_Landmarks_SecondHypothesis_RightRangeMax)
            t_Landmarks:add(f_Landmarks_LaneMatrix_LeftLanes, v_Landmarks_LaneMatrix_LeftLanes)
            t_Landmarks:add(f_Landmarks_LaneMatrix_RightLanes, v_Landmarks_LaneMatrix_RightLanes)
            t_Landmarks:add(f_Landmarks_DistanceToBorder_Left, v_Landmarks_DistanceToBorder_Left)
            t_Landmarks:add(f_Landmarks_DistanceToBorder_Right, v_Landmarks_DistanceToBorder_Right)
            t_Landmarks:add(f_Landmarks_Tunnel_InvalidFlags, v_Landmarks_Tunnel_InvalidFlags)
            t_Landmarks:add(f_Landmarks_Tunnel_Distance, v_Landmarks_Tunnel_Distance)
            t_Landmarks:add(f_Landmarks_Tunnel_ExistanceProbability, v_Landmarks_Tunnel_ExistanceProbability)

            return true;

        elseif v_methodID:uint() == MESSAGE_ID_FIELD_OF_VIEW then
            REGION_SIZE = 152
            MAX_REGION_COUNT = 40

            local offset = some_ip_payload_offset
            local v_FieldOfView_Timestamp_Nanoseconds = buf(offset + 0, 4)
            local v_FieldOfView_Timestamp_Seconds = buf(offset + 4, 4)
            local v_FieldOfView_Timestamp_SyncStatus = buf(offset + 8, 1)
            local v_FieldOfView_SensorStatus = buf(offset + 9, 1)
            local offset_region_start = offset + 9 + 1

            local region_count = math.floor((buf_len - offset_region_start) / REGION_SIZE)
            local size = 10 + region_count * REGION_SIZE

            local t_FieldOfView = t:add(p_ARS548_FieldOfView, buf(offset, size), nil, "(" .. size .. " bytes)")

            t_FieldOfView:add(f_FieldOfView_Timestamp_Nanoseconds, v_FieldOfView_Timestamp_Nanoseconds)
            t_FieldOfView:add(f_FieldOfView_Timestamp_Seconds, v_FieldOfView_Timestamp_Seconds)
            t_FieldOfView:add(f_FieldOfView_Timestamp_SyncStatus, v_FieldOfView_Timestamp_SyncStatus)
            t_FieldOfView:add(f_FieldOfView_SensorStatus, v_FieldOfView_SensorStatus)

            local i = 0
            while (i < MAX_REGION_COUNT and i < region_count) do
                offset = offset_region_start + i * REGION_SIZE

                local v_Region_s_AzimuthRange_Start = buf(offset + 0, 2)
                local v_Region_s_AzimuthRange_End = buf(offset + 2, 2)
                local v_Region_f_MaximumDetectionRange_Pedestrian = buf(offset + 4, 4)
                local v_Region_f_MaximumDetectionRange_Motorbike = buf(offset + 8, 4)
                local v_Region_f_MaximumDetectionRange_Car = buf(offset + 12, 4)
                local v_Region_u_InvalidFlags = buf(offset + 16, 1)
                local v_Region_u_Blockage_Status = buf(offset + 17, 1)
                local v_Region_u_Blockage_Classification = buf(offset + 18, 1)

                local t_region = t_FieldOfView:add(p_ARS548_Region, buf(offset, REGION_SIZE)):append_text(" [" .. (i + 1) .. "]")
                t_region:add(f_Region_s_AzimuthRange_Start, v_Region_s_AzimuthRange_Start)
                t_region:add(f_Region_s_AzimuthRange_End, v_Region_s_AzimuthRange_End)
                t_region:add(f_Region_f_MaximumDetectionRange_Pedestrian, v_Region_f_MaximumDetectionRange_Pedestrian)
                t_region:add(f_Region_f_MaximumDetectionRange_Motorbike, v_Region_f_MaximumDetectionRange_Motorbike)
                t_region:add(f_Region_f_MaximumDetectionRange_Car, v_Region_f_MaximumDetectionRange_Car)
                t_region:add(f_Region_u_InvalidFlags, v_Region_u_InvalidFlags)
                t_region:add(f_Region_u_Blockage_Status, v_Region_u_Blockage_Status)
                t_region:add(f_Region_u_Blockage_Classification, v_Region_u_Blockage_Classification)

                i = i + 1
            end

            return true;

        elseif v_methodID:uint() == MESSAGE_ID_EGO_SPEED then
            addEgoSpeed(some_ip_payload_offset)
            return true;

        elseif v_methodID:uint() == MESSAGE_ID_SENSOR_STATUS then
            addSensorStatus(some_ip_payload_offset)
            return true;

        elseif v_methodID:uint() == MESSAGE_ID_SENSOR_CONFIGURATION then
            addSensorConfiguration(some_ip_payload_offset)
            return true;

        else
            local sub_payload_len = buf_len - 36
            local v_payload = buf(36, sub_payload_len)
            t:add(f_payload, v_payload):append_text(" (" .. sub_payload_len .. " bytes)")
            return true;
        end


    end

    --这里是获取data这个解析器
    local data_dis = Dissector.get("data")

    --这段代码是目的Packet符合条件时，被Wireshark自动调用的，是p_ARS548的成员方法
    function p_ARS548.dissector(buf, pkt, root)
        if ARS_dissector(buf, pkt, root) then
            --valid ARS548 diagram
        else
            --data这个dissector几乎是必不可少的；当发现不是我的协议时，就应该调用data
            data_dis:call(buf, pkt, root)
        end
    end

    local udp_encap_table = DissectorTable.get("udp.port")
    -- 通过 DissectorTable 指定协议要过滤的目标端口
    udp_encap_table:add(42101, p_ARS548)
    udp_encap_table:add(42102, p_ARS548)
end
